# Package Manifest — rtxEngine Terminal Edition v13 Handoff 187 RC2.1

- `rtxEngine-terminal-v13.py` — terminal engine with RC2 import-aware Ada injection hardening plus RC2.1 launch-option safety repair
- `providers/rtxforge-native-mfg-v3e/OptiScaler.dll` — exact pinned Ada NativeMFG v3e runtime (unchanged core)
- `providers/rtxforge-native-mfg-v3e/rtxforge-loader.json` — pinned runtime identity manifest
- `tests/test_v13_core_hardening.py` — transaction/security/runtime-policy regressions, including RC2 fixtures and RC2.1 launch repair coverage
- `tests/test_v13_deep_clean.py`
- `tests/test_v13_pristine_reset.py`
- `RUN_TESTS.sh`
- `TEST_RESULTS.md`
- `DEVELOPMENT_HANDOFF.md`

Bundled Ada DLL SHA-256:
`95580ebc7d2f562d6d99cd798587f757a51cd7bd52e24b0895c42414c3a3c2e8`

RC2 does not ship a second Ada MFG provider or user-facing route selector. NR remains disabled on the integrated Ada path.

RC2.1 does not change the bundled v3e runtime DLL or Ada MFG execution code. It changes only launch-option generation/merge safety and documentation/tests.
