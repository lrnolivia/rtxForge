# rtxEngine · Terminal Edition v13 — Handoff 187 RC2.1

## Status
**Launch-safety hotfix over RC2. Automated gate is clean; universal runtime validation is still pending.**

## RC2.1 launch-options hotfix

RC2 exposed a real launch-metadata regression during live testing: its merge path hard-coded `PROTON_NVIDIA_NVCUDA=1` into every synced game even when the current runtime contract did not require it. On Proton forks that implement this variable it enables an alternate `nvcuda.dll` path; that is unrelated to DLSS-G injection and can change game compatibility.

RC2.1 therefore:

- removes `PROTON_NVIDIA_NVCUDA=1` from all newly generated rtxEngine launch options;
- keeps `PROTON_NVIDIA_NVCUDA` in the historical ownership set so launch lines written by RC1/RC2 can be repaired or restored safely;
- makes the `required` launch string authoritative instead of unconditionally appending scalar variables inside the merge function;
- recognizes only the true **leading shell-assignment segment** as environment assignments;
- refuses automatic rewrite when an rtxEngine-managed-looking assignment occurs after `gamescope`, `env`, or another wrapper command, because moving such a token would change command structure;
- preserves existing `WINEDLLOVERRIDES` entries, including known-required values such as Halo Campaign Evolved's `dwmapi=n,b`, while adding only the selected rtxEngine proxy;
- can repair already-synced RC2 LaunchOptions **without reinstalling game files**: run menu `5 — Sync launch options into Steam` with Steam closed.

The active launch contract is now intentionally minimal:

```text
WINEDLLOVERRIDES="<selected proxy plus preserved existing overrides>=n,b" PROTON_ENABLE_NVAPI=1 %command%
```

No NVCUDA override is added.

Handoff 187 RC1 restored the exact historical integrated RTXForge NativeMFG v3e runtime and succeeded in six real Ada titles, including the original The Outer Worlds 2 golden canary. The user's broader 18-game library test also showed that the same installation was not universal: several titles failed to launch, crashed, froze, or launched without a working MFG hook.

RC2 keeps one user-facing Ada MFG architecture. It does **not** add route/profile selection. Instead it hardens how the same v3e runtime is injected and configured so a game that already proved MFG continues using its working proxy, while an unproven/failed target may move to a positively imported supported loader automatically.

NR remains intentionally **disabled on Ada**. Do not mix NR debugging into this MFG compatibility milestone.

## RC1 live matrix — 2026-09-11

### Working as expected
- Avowed
- Clair Obscur: Expedition 33 — MFG worked even though the OptiScaler menu did not appear
- FINAL FANTASY VII REBIRTH
- Forza Horizon 6
- Halo Campaign Evolved
- The Outer Worlds 2

### Loaded but MFG did not work
- Avatar: Frontiers of Pandora — playable; no OptiScaler menu; no MFG
- inZOI — MFG options visible, but no working MFG; no OptiScaler menu

### Crash / hang / launch failure
- 007 First Light — would not launch
- Crimson Desert Enhanced — crashed after splash
- Cyberpunk 2077 — `flatlined` during load
- Dragon Age: The Veilguard — crashed on load
- Hogwarts Legacy — froze on Preparing Shaders
- PRAGMATA — would not launch
- STAR WARS Jedi: Survivor — would not launch; title was already known finicky
- Star Wars Outlaws — would not launch
- Starfield — would not launch
- The Witcher 3: Wild Hunt — failed to launch

This matrix is evidence, not a hardcoded game whitelist. RC2 deliberately learns from runtime state and executable imports rather than assigning per-game user-facing recipes.

## Ada runtime identity — unchanged from RC1
Bundled runtime:
- Name: `RTXForge NativeMFG v3e`
- Fork commit: `deca7b7a8f1953de3cf6fe2731ede440b3ddaadf`
- Upstream OptiScaler base: `7b7220bbb4994a9c8ae60cfc75a44cb67995efb8`
- DLL SHA-256: `95580ebc7d2f562d6d99cd798587f757a51cd7bd52e24b0895c42414c3a3c2e8`
- Capability: `RTXForge.NativeMfgMenu.v3e`
- Historical CI run: `34455052784`

The compiled MFG core is intentionally unchanged in RC2. This isolates delivery/configuration compatibility first. If a game still crashes after RC2 proves the v3e execution marker is reached, the next experiment must change the compiled runtime rather than adding more installer guesses.

## What RC2 changes

### 1. Import-aware automatic proxy selection
Integrated Ada installs now parse the selected game EXE's normal PE import table and prefer an **actually imported, officially supported OptiScaler proxy name** over an unproven generic graphics fallback.

RC2-supported candidates, in preference order:
- `wininet.dll`
- `winhttp.dll`
- `winmm.dll`
- `dbghelp.dll`
- `dxgi.dll`
- `version.dll`
- `d3d12.dll`

Unknown existing game/mod DLLs are never stolen or overwritten. ReShade ownership of `dxgi.dll` is preserved.

### 2. Preserve a proxy that has already proven MFG
Before refreshing an existing integrated Ada install, RC2 inspects `OptiScaler.log` for the exact v3e execution marker:

`RTXForge.NativeMfgMenu.v3e: applied native interpolation request`

If that marker exists, the current proxy is treated as **runtime-proven** and kept ahead of alternative imports. This protects RC1 winners instead of changing them just because another proxy is technically available.

If the marker is absent, RC2 may transactionally migrate an RC1 `dxgi.dll` fallback to a positively imported supported proxy. Old engine-owned proxy bytes are retired through the existing ownership-transfer machinery; external/game-owned files remain protected.

### 3. Runtime validation no longer depends on the overlay
Expedition 33 proved that “no OptiScaler menu” does not mean “MFG failed.” Audit/report output now records runtime evidence separately from overlay visibility:
- `mfg-applied`
- `native-bridge-seen`
- `log-present`
- `runtime-error`
- `not-observed`

A successful v3e execution marker is the positive signal.

### 4. Less invasive Ada configuration
For the integrated Ada path RC2 now:
- keeps `[Spoofing] Dxgi=false`;
- keeps `[Spoofing] StreamlineSpoofing=false`;
- does **not** force `Dx12Upscaler=dlss`;
- preserves the native/game/upstream SR route;
- keeps the same integrated native `dlssg -> dlssg` MFG bridge;
- keeps NR disabled.

This reduces unrelated DXGI/Streamline/upscaler behavior changes while testing MFG compatibility.

### 5. Conditional EOS overlay blocker
RC2 detects Epic Online Services overlay DLLs without following symlinks or nested filesystem pivots. When detected, it enables OptiScaler's built-in:

```ini
[Hotfix]
DisableOverlays=true
```

The setting is not forced globally, avoiding unnecessary impact on unrelated titles/Steam Input.

### 6. ReShade launch-option coexistence fixed
When ReShade owns `dxgi.dll` and OptiScaler uses another proxy, generated Proton launch options now include **both** required native overrides, not only the old `version.dll` special case.

## Ada MFG policy retained
```ini
[FrameGen]
External=false
Enabled=true
FGInput=dlssg
FGOutput=dlssg
FGNvngxReplacement=none

[DLSSG]
AmpereMfgUnlock=false
AdaMfgUnlock=true
AdaBlackwellKernels=true
InterpolationCount=auto
OverrideInterpolationCount=auto
OverrideForceDMFG=false
ForceDMFG=false

[NvApi]
DisableFlipMetering=true
DisableReflexSync=true

[DlssNr]
Enabled=false
```

## Upgrade behavior
Install/update RC2 **over the existing RC1/186 state**. Do not manually uninstall or delete game DLLs first.

The existing v13 transaction model remains authoritative:
- baseline before mutation;
- safe ownership transfer when proxy name changes;
- external-drift refusal;
- atomic state writes;
- crash/retry recovery;
- full pre-rtxEngine restore on uninstall.

## Automated verification for RC2
- `pytest -q`: **200 passed, 10 subtests passed**
- unittest subtests reported through pytest: **10 passed**
- `python3 -m py_compile rtxEngine-terminal-v13.py`: **PASS**
- exact bundled v3e DLL identity remains pinned and verified.

New RC2 regressions prove:
1. imported `wininet.dll` is preferred over an unproven `dxgi.dll` fallback;
2. a failed/unproven RC1 `dxgi.dll` install can migrate transactionally to a positive imported proxy;
3. a proxy with a real v3e MFG execution marker is preserved;
4. ReShade + non-DXGI OptiScaler proxy produces both Proton overrides and preserves ReShade bytes;
5. integrated Ada minimizes spoofing and does not force the SR route;
6. EOS overlay detection enables the built-in blocker only when applicable;
7. runtime health uses execution markers rather than menu visibility.

## RC2 live acceptance sequence
Do **not** rerun the full 18-game matrix initially.

Use three targeted states:
1. **The Outer Worlds 2** (or Avowed) — regression baseline. It must remain working and should preserve the already-proven proxy when the v3e marker is present.
2. **Cyberpunk 2077** — previous hard-crash/flatline case. It tests whether import-aware proxy selection + minimized spoofing avoid the early failure.
3. **Avatar: Frontiers of Pandora** — previous “boots but no hook/MFG” case. It tests whether RC2 reaches the game process through a positive imported proxy.

After each launch, run Audit. `runtime=mfg-applied` is the success signal even if no OptiScaler menu appears.

### Decision gate
- If the baseline still works and either failed class improves: continue this single-path hardening line.
- If Cyberpunk still crashes **and Audit/log evidence proves v3e entered the runtime**, stop changing installer/proxy policy. The next RC must be a controlled C++ runtime-hook experiment.
- If Avatar still has `not-observed`, continue investigating loader reach/process placement rather than changing MFG logic.

## Next milestone after MFG compatibility
**188 — Proton Neural Rendering restoration**, but only after 187 is stable enough that NR work can preserve a known-good MFG baseline.

Exact Steam depot-manifest deletion remains read-only/experimental and is not enabled here.
