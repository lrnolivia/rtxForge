import importlib.util
import io
import os
import json
import hashlib
import subprocess
import zipfile
import struct
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "rtxEngine-terminal-v13.py"


def load_engine():
    name = f"rtxengine_core_test_{id(object())}"
    spec = importlib.util.spec_from_file_location(name, SCRIPT)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _kv_cstr(value: str) -> bytes:
    return value.encode("utf-8", errors="surrogateescape") + b"\x00"


def _kv_string(key: str, value: str) -> bytes:
    return b"\x01" + _kv_cstr(key) + _kv_cstr(value)


def _kv_int(key: str, value: int) -> bytes:
    return b"\x02" + _kv_cstr(key) + struct.pack("<i", value)


def make_shortcuts_fixture(game, launch: str | None = "MANGOHUD=1 %command%") -> bytes:
    # Real shortcuts.vdf framing: object `shortcuts`, shortcut objects, then one
    # terminator for the shortcuts map plus the final binary-KV root terminator.
    obj = bytearray()
    obj += b"\x00" + _kv_cstr("0")
    obj += _kv_string("AppName", game.name)
    obj += _kv_string("exe", f'"{game.exe}"')
    obj += _kv_string("StartDir", f'"{game.root}"')
    obj += _kv_int("appid", 0x1234567)
    if launch is not None:
        obj += _kv_string("LaunchOptions", launch)
    # Include a nested/unknown-to-us field so surgical edits prove they do not
    # flatten or reconstruct the rest of the shortcut object.
    obj += b"\x00" + _kv_cstr("tags") + _kv_string("0", "Favorite") + b"\x08"
    obj += b"\x08"
    return b"\x00" + _kv_cstr("shortcuts") + bytes(obj) + b"\x08\x08"


def write_minimal_pe(path: Path, imports: list[str]) -> None:
    # Minimal PE32+ image sufficient for rtxEngine's dependency-free normal
    # import-table parser. It is a parser fixture, not an executable program.
    pe_off = 0x80
    opt_size = 0xF0
    raw_off = 0x200
    section_va = 0x1000
    section_size = 0x600
    data = bytearray(raw_off + section_size)
    data[:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, pe_off)
    data[pe_off:pe_off + 4] = b"PE\0\0"
    coff = pe_off + 4
    struct.pack_into("<H", data, coff, 0x8664)
    struct.pack_into("<H", data, coff + 2, 1)
    struct.pack_into("<H", data, coff + 16, opt_size)
    opt = coff + 20
    struct.pack_into("<H", data, opt, 0x20B)
    # Import data-directory entry (directory index 1).
    import_rva = section_va
    import_size = (len(imports) + 1) * 20
    struct.pack_into("<II", data, opt + 112 + 8, import_rva, import_size)

    sec = opt + opt_size
    data[sec:sec + 8] = b".rdata\0\0"
    struct.pack_into("<I", data, sec + 8, section_size)
    struct.pack_into("<I", data, sec + 12, section_va)
    struct.pack_into("<I", data, sec + 16, section_size)
    struct.pack_into("<I", data, sec + 20, raw_off)

    name_cursor = raw_off + 0x180
    for i, name in enumerate(imports):
        desc = raw_off + i * 20
        name_rva = section_va + (name_cursor - raw_off)
        struct.pack_into("<IIIII", data, desc, 0x1300, 0, 0, name_rva, 0x1400)
        raw = name.encode("ascii") + b"\0"
        data[name_cursor:name_cursor + len(raw)] = raw
        name_cursor += len(raw)
    path.write_bytes(data)


class CoreHardeningTests(unittest.TestCase):
    def setUp(self):
        self.m = load_engine()
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.m.STATE_ROOT = self.base / "state"
        self.drive = self.base / "Games"
        self.target = self.drive / "SteamLibrary" / "steamapps" / "common" / "Fixture" / "Binaries" / "Win64"
        self.target.mkdir(parents=True)
        self.exe = self.target / "game.exe"
        self.exe.write_bytes(b"MZfixture")
        self.game = self.m.Game(
            "A", "Fixture", self.target.parents[2], "Steam", "123", None,
            self.exe, self.target,
        )

    def tearDown(self):
        self.tmp.cleanup()

    def _baseline(self, **updates):
        data = {
            "schema": 13,
            "status": "active",
            "created_utc": self.m.now_iso(),
            "name": "Fixture",
            "source": "Steam",
            "appid": "123",
            "exe": str(self.exe),
            "target_dir": str(self.target),
            "originals": {},
            "managed_paths": [],
            "history": [],
            "current": {"installed_hashes": {}},
        }
        data.update(updates)
        self.m.state_dir_for(self.target).mkdir(parents=True, exist_ok=True)
        self.m.save_json_atomic(self.m.baseline_path(self.target), data)
        return data

    def test_next_state_retirement_cleans_safe_stale_trash_first(self):
        trash = self.m._state_trash_root()
        trash.mkdir(parents=True)
        stale = trash / "stale-old"
        stale.mkdir()
        (stale / "old.bin").write_bytes(b"old")

        state_dir = self.m.state_dir_for(self.target)
        backup = state_dir / "baseline-backup"
        backup.mkdir(parents=True)
        (backup / "payload.bin").write_bytes(b"payload")
        self.m.discard_consumed_baseline_backup(self.target)
        self.assertFalse(stale.exists())
        self.assertFalse(backup.exists())
        self.assertEqual(list(trash.iterdir()), [])

    def test_consumed_backup_is_retired_before_recursive_cleanup_failure(self):
        state_dir = self.m.state_dir_for(self.target)
        backup = state_dir / "baseline-backup"
        backup.mkdir(parents=True)
        (backup / "payload.bin").write_bytes(b"payload")
        real_rmtree = self.m.shutil.rmtree
        def fail_trash_cleanup(path, *args, **kwargs):
            if "state-trash" in Path(path).parts:
                raise OSError("simulated crashy trash cleanup")
            return real_rmtree(path, *args, **kwargs)
        self.m.shutil.rmtree = fail_trash_cleanup
        try:
            retired = self.m.discard_consumed_baseline_backup(self.target)
        finally:
            self.m.shutil.rmtree = real_rmtree
        self.assertGreater(retired, 0)
        self.assertFalse(backup.exists(), "active baseline-backup name must be gone before recursive cleanup")
        trash = self.m._state_trash_root()
        tombstones = list(trash.iterdir())
        self.assertEqual(len(tombstones), 1)
        self.assertTrue((tombstones[0] / "payload.bin").is_file())
        self.assertIsNone(self.m.quarantine_orphan_baseline_backup(self.target))

    def test_target_history_retention_keeps_current_recovery_slot_regardless_of_mtime(self):
        state = self.m._validated_state_dir(self.target)
        recovery_root = state / "recovery-before-restore"
        recovery_root.mkdir(parents=True)
        current = recovery_root / "current-slot"
        stale = recovery_root / "newer-stale-slot"
        current.mkdir()
        stale.mkdir()
        (current / "OptiScaler.ini").write_bytes(b"preserved-user-drift")
        (stale / "old.txt").write_bytes(b"stale")
        os.utime(current, ns=(1, 1))
        os.utime(stale, ns=(999, 999))

        self.m.prune_target_history(self.target, protected_recovery=current)

        self.assertTrue(current.is_dir())
        self.assertEqual((current / "OptiScaler.ini").read_bytes(), b"preserved-user-drift")
        self.assertFalse(stale.exists())

    def test_target_history_retention_drops_empty_current_recovery_slot(self):
        state = self.m._validated_state_dir(self.target)
        recovery_root = state / "recovery-before-restore"
        current = recovery_root / "empty-slot"
        current.mkdir(parents=True)
        self.m.prune_target_history(self.target, protected_recovery=current)
        self.assertFalse(current.exists())
        self.assertFalse(recovery_root.exists())

    def test_steam_backup_generated_child_symlink_pivot_is_refused(self):
        config = self._steam_localconfig('gamescope %command%')
        backup_root = self.m._validated_state_namespace("steam-config-backups")
        backup_root.mkdir(parents=True)
        outside = self.base / "outside-steam-backup"
        outside.mkdir()
        stamp = "20990101-000000"
        (backup_root / stamp).symlink_to(outside, target_is_directory=True)

        with patch.object(self.m, "now_stamp", return_value=stamp):
            with self.assertRaises(self.m.Stop) as cm:
                self.m.backup_steam_config(config, "42")
        self.assertIn("symlink refused", str(cm.exception))
        self.assertEqual(list(outside.iterdir()), [])

    def test_steam_backup_prune_never_deletes_explicit_prejournal_generation(self):
        root = self.m.STATE_ROOT / "steam-config-backups"
        protected = root / "old-but-current"
        newer1 = root / "newer-1"
        newer2 = root / "newer-2"
        for path in (protected, newer1, newer2):
            path.mkdir(parents=True)
            (path / "x").write_text(path.name, encoding="utf-8")
        # Deliberately make the just-created/current generation look oldest;
        # correctness must not rely on its mtime winning the retention sort.
        os.utime(protected, ns=(1, 1))
        os.utime(newer1, ns=(2, 2))
        os.utime(newer2, ns=(3, 3))
        self.m.prune_steam_config_backups(keep=1, extra_protected={protected})
        self.assertTrue(protected.is_dir())
        self.assertFalse(newer1.exists())
        self.assertTrue(newer2.is_dir())

    def test_atomic_write_fsyncs_containing_directory_after_replace(self):
        target = self.base / "durable" / "state.json"
        real_fsync = self.m.os.fsync
        calls = []
        def tracking_fsync(fd):
            calls.append(fd)
            return real_fsync(fd)
        with patch.object(self.m.os, "fsync", side_effect=tracking_fsync):
            self.m.atomic_write(target, b"durable")
        self.assertEqual(target.read_bytes(), b"durable")
        # One fsync is the temporary file; at least one later fsync is the
        # containing directory after os.replace().
        self.assertGreaterEqual(len(calls), 2)

    def test_copy_verified_failure_never_replaces_existing_destination(self):
        src = self.base / "src.bin"
        dst = self.base / "dst.bin"
        src.write_bytes(b"new-recovery-bytes")
        dst.write_bytes(b"old-safe-bytes")
        real_copy2 = self.m.shutil.copy2

        def partial_then_fail(source, target, *args, **kwargs):
            target = Path(target)
            target.write_bytes(b"partial")
            raise OSError("simulated copy failure")

        with patch.object(self.m.shutil, "copy2", side_effect=partial_then_fail):
            with self.assertRaises(OSError):
                self.m.copy_verified(src, dst)
        self.assertEqual(dst.read_bytes(), b"old-safe-bytes")
        self.assertFalse(any(dst.parent.glob(f".{dst.name}.rtxforge-copy-*")))

    def test_mutation_lock_blocks_second_process_and_releases_cleanly(self):
        probe = self.base / "lock_probe.py"
        probe.write_text(
            "import importlib.util, os, sys\n"
            f"script = {str(SCRIPT)!r}\n"
            "spec = importlib.util.spec_from_file_location('rtxengine_lock_probe', script)\n"
            "m = importlib.util.module_from_spec(spec); sys.modules[spec.name] = m; spec.loader.exec_module(m)\n"
            "try:\n"
            "    with m.mutation_lock():\n"
            "        print('ACQUIRED')\n"
            "except m.Stop as exc:\n"
            "    print('BUSY:' + str(exc))\n",
            encoding="utf-8",
        )
        env = os.environ.copy()
        env["RTXFORGE_DLSS_UNLOCKED_STATE"] = str(self.m.STATE_ROOT)
        with self.m.mutation_lock():
            blocked = subprocess.run(
                [sys.executable, str(probe)], env=env, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
            )
            self.assertIn("BUSY:Another rtxEngine mutating operation is already running", blocked.stdout)
        released = subprocess.run(
            [sys.executable, str(probe)], env=env, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
        )
        self.assertIn("ACQUIRED", released.stdout)

    def test_mutation_lock_refuses_symlink_lockfile(self):
        self.m.STATE_ROOT.mkdir(parents=True)
        outside = self.base / "outside-lock"
        outside.write_text("outside", encoding="utf-8")
        (self.m.STATE_ROOT / ".writer.lock").symlink_to(outside)
        with self.assertRaises(self.m.Stop) as cm:
            with self.m.mutation_lock():
                pass
        self.assertIn("writer lock symlink refused", str(cm.exception))
        self.assertEqual(outside.read_text(encoding="utf-8"), "outside")

    def test_durable_replace_and_unlink_sync_parent_directory(self):
        parent = self.base / "durable-names"
        parent.mkdir()
        src = parent / "old"
        dst = parent / "new"
        src.write_bytes(b"x")
        synced = []
        with patch.object(self.m, "_fsync_dir", side_effect=lambda p: synced.append(Path(p))):
            self.m.durable_replace(src, dst)
            self.assertTrue(dst.is_file())
            self.assertIn(parent, synced)
            synced.clear()
            self.m.durable_unlink(dst)
            self.assertFalse(dst.exists())
            self.assertIn(parent, synced)

    def test_restore_drift_copy_failure_aborts_before_live_file_deletion(self):
        self.game.dlss = True
        self.game.dlssg = True
        meta = {"name": "fixture.zip", "sha256": "a" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), meta, "sm86")
        live = self.target / "OptiScaler.ini"
        live.write_bytes(b"user-edited-after-install")
        real_copy = self.m.copy_verified

        def fail_recovery_copy(src, dst):
            if "recovery-before-restore" in str(dst):
                raise OSError("simulated recovery media failure")
            return real_copy(src, dst)

        with patch.object(self.m, "copy_verified", side_effect=fail_recovery_copy):
            with self.assertRaises(OSError):
                self.m.restore_target(self.game)
        self.assertTrue(live.is_file())
        self.assertEqual(live.read_bytes(), b"user-edited-after-install")
        self.assertTrue(self.m.baseline_path(self.target).is_file())

    def test_regular_tree_backup_is_flushed_before_manifest_commit(self):
        source = self.base / "tree-source"
        source.mkdir()
        (source / "a.bin").write_bytes(b"a")
        backup_root = self.m.state_dir_for(self.target) / "baseline-backup"
        backup_root.mkdir(parents=True)
        flushed = []
        real = self.m._fsync_tree
        with patch.object(self.m, "_fsync_tree", side_effect=lambda p: (flushed.append(Path(p)), real(p))[1]):
            info = self.m.backup_tree(source, backup_root, "OptiScaler")
        self.assertEqual(flushed, [Path(info["backup"])])
        self.assertTrue(Path(info["manifest"]).is_file())

    def test_state_child_namespaces_refuse_symlink_pivots(self):
        self.m.STATE_ROOT.mkdir(parents=True)
        outside = self.base / "outside-state-namespace"
        outside.mkdir()
        for name in ("steam-transactions", "steam-config-backups", "state-trash", "deep-clean-receipts", "pristine-reset-receipts"):
            link = self.m.STATE_ROOT / name
            link.symlink_to(outside, target_is_directory=True)
            try:
                with self.subTest(name=name):
                    with self.assertRaises(self.m.Stop):
                        self.m._validated_state_namespace(name)
            finally:
                link.unlink()

    def test_verify_queue_symlink_is_refused_before_read(self):
        self.m.STATE_ROOT.mkdir(parents=True)
        outside = self.base / "outside-queue.json"
        outside.write_text(json.dumps({"schema": 2, "remaining": [], "in_flight": None}), encoding="utf-8")
        queue = self.m.STATE_ROOT / "steam-verify-queue.json"
        queue.symlink_to(outside)
        with self.assertRaises(self.m.Stop) as cm:
            self.m._load_verify_queue()
        self.assertIn("queue symlink refused", str(cm.exception))
        self.assertTrue(outside.is_file())

    def test_steam_transaction_journal_symlink_is_refused_before_read(self):
        tx_root = self.m._steam_transaction_root()
        tx_root.mkdir(parents=True)
        outside = self.base / "outside-tx.json"
        outside.write_text(json.dumps({"schema": 1, "phase": "prepared"}), encoding="utf-8")
        (tx_root / "evil.json").symlink_to(outside)
        with self.assertRaises(self.m.Stop) as cm:
            self.m.load_pending_steam_transactions()
        self.assertIn("journal symlink refused", str(cm.exception))

        backup_root = self.m._validated_state_namespace("steam-config-backups")
        backup_root.mkdir(parents=True)
        generation = backup_root / "generation"
        generation.mkdir()
        self.assertIsNone(self.m._active_steam_backup_generations(backup_root))
        self.m.prune_steam_config_backups(keep=0)
        self.assertTrue(generation.is_dir(), "ambiguous journal state must disable retention pruning")

    def test_persisted_traversal_is_rejected_before_live_mutation(self):
        victim = self.base / "outside.txt"
        victim.write_text("keep", encoding="utf-8")
        b = self._baseline(managed_paths=["../../../../../../outside.txt"])
        with self.assertRaises(self.m.Stop):
            self.m.verify_baseline_integrity(self.target, b, adopt_legacy=False)
        self.assertEqual(victim.read_text(encoding="utf-8"), "keep")

    def test_baseline_backup_root_symlink_pivot_is_rejected(self):
        state = self.m._validated_state_dir(self.target)
        state.mkdir(parents=True)
        outside = self.base / "outside-backups"
        outside.mkdir()
        payload = outside / "dxgi.dll"
        payload.write_bytes(b"outside")
        (state / "baseline-backup").symlink_to(outside, target_is_directory=True)
        with self.assertRaises(self.m.Stop) as cm:
            self.m._baseline_backup_member(self.target, str(payload))
        self.assertIn("backup root symlink", str(cm.exception))

    def test_restore_recovery_root_symlink_pivot_is_rejected(self):
        state = self.m._validated_state_dir(self.target)
        state.mkdir(parents=True)
        outside = self.base / "outside-recovery-root"
        outside.mkdir()
        (state / "recovery-before-restore").symlink_to(outside, target_is_directory=True)
        slot = outside / "slot"
        slot.mkdir()
        with self.assertRaises(self.m.Stop) as cm:
            self.m._validate_restore_recovery_dir(self.target, str(slot))
        self.assertIn("recovery root symlink", str(cm.exception))

    def test_backup_path_escape_is_rejected(self):
        external = self.base / "evil-backup.dll"
        external.write_bytes(b"evil")
        b = self._baseline(originals={
            "dxgi.dll": {
                "kind": "file", "existed": True,
                "backup": str(external),
                "sha256": self.m.sha256_file(external),
                "mode": 0o644,
            }
        })
        with self.assertRaises(self.m.Stop):
            self.m.verify_baseline_integrity(self.target, b, adopt_legacy=False)

    def test_tree_manifest_detects_tamper_before_restore_deletes_live_tree(self):
        live = self.target / "OptiScaler"
        live.mkdir()
        (live / "current.bin").write_bytes(b"current")
        backup_root = self.m.state_dir_for(self.target) / "baseline-backup"
        backup_root.mkdir(parents=True)
        source = self.base / "old-opti"
        source.mkdir()
        (source / "old.bin").write_bytes(b"original")
        info = self.m.backup_tree(source, backup_root, "OptiScaler")
        b = self._baseline(
            originals={"OptiScaler/": info},
            managed_paths=["OptiScaler/"],
            current={"installed_hashes": {}},
        )
        # Damage the baseline after its manifest was written.
        (Path(info["backup"]) / "old.bin").write_bytes(b"tampered")
        with self.assertRaises(self.m.Stop):
            self.m.restore_target(self.game)
        self.assertTrue(live.is_dir())
        self.assertEqual((live / "current.bin").read_bytes(), b"current")

    def test_tree_baseline_refuses_source_change_during_copy(self):
        source = self.base / "moving-opti"
        source.mkdir()
        live = source / "core.dll"
        live.write_bytes(b"before")
        backup_root = self.m.state_dir_for(self.target) / "baseline-backup"
        backup_root.mkdir(parents=True)
        real_copytree = self.m.shutil.copytree

        def copy_then_mutate(src, dst, *args, **kwargs):
            result = real_copytree(src, dst, *args, **kwargs)
            live.write_bytes(b"after")
            return result

        with patch.object(self.m.shutil, "copytree", side_effect=copy_then_mutate):
            with self.assertRaises(self.m.Stop) as cm:
                self.m.backup_tree(source, backup_root, "OptiScaler")
        self.assertIn("changed while baseline backup", str(cm.exception))
        self.assertEqual(live.read_bytes(), b"after")

    def test_legacy_tree_gets_integrity_metadata_without_touching_live_game(self):
        backup_root = self.m.state_dir_for(self.target) / "baseline-backup"
        tree = backup_root / "trees" / "OptiScaler"
        tree.mkdir(parents=True)
        (tree / "old.bin").write_bytes(b"old")
        b = self._baseline(originals={
            "OptiScaler/": {
                "kind": "tree", "existed": True,
                "backup": str(tree), "bytes": 3,
            }
        })
        self.m.verify_baseline_integrity(self.target, b, adopt_legacy=True)
        reloaded = self.m.load_baseline(self.target)
        info = reloaded["originals"]["OptiScaler/"]
        self.assertIn("manifest", info)
        self.assertIn("manifest_sha256", info)
        self.assertIn("tree_sha256", info)
        self.assertTrue(Path(info["manifest"]).is_file())

    def test_malicious_tar_member_is_rejected(self):
        archive = self.base / "bad.tar"
        with tarfile.open(archive, "w") as tf:
            payload = b"oops"
            ti = tarfile.TarInfo("../escape")
            ti.size = len(payload)
            tf.addfile(ti, io.BytesIO(payload))
        with self.assertRaises(self.m.Stop):
            self.m._validate_tar_archive(archive, expected_top="OptiScaler", exact_file=False)

    def test_duplicate_tar_members_are_refused(self):
        archive = self.base / "duplicate.tar"
        with tarfile.open(archive, "w") as tf:
            for payload in (b"first", b"second"):
                ti = tarfile.TarInfo("OptiScaler/core.dll")
                ti.size = len(payload)
                tf.addfile(ti, io.BytesIO(payload))
        with self.assertRaises(self.m.Stop) as cm:
            self.m._validate_tar_archive(archive, expected_top="OptiScaler", exact_file=False)
        self.assertIn("Duplicate tar member", str(cm.exception))

    def test_baseline_json_symlink_is_refused_before_read(self):
        state = self.m._validated_state_dir(self.target)
        state.mkdir(parents=True)
        outside = self.base / "outside-baseline.json"
        outside.write_text(json.dumps({
            "schema": 13, "target_dir": str(self.target), "managed_paths": [], "originals": {}
        }), encoding="utf-8")
        (state / "baseline.json").symlink_to(outside)
        with self.assertRaises(self.m.Stop) as cm:
            self.m.load_baseline(self.target)
        self.assertIn("Baseline state file symlink refused", str(cm.exception))
        self.assertTrue(outside.is_file())

    def test_corrupt_state_is_visible_not_silently_hidden(self):
        bad = self.m.STATE_ROOT / "targets" / "bad" / "baseline.json"
        bad.parent.mkdir(parents=True)
        bad.write_text("{ definitely not json", encoding="utf-8")
        messages = []
        self.m.warn = messages.append
        games = self.m.load_installed_states_under_drive(self.drive)
        self.assertEqual(games, [])
        self.assertTrue(any("Corrupt/unreadable install state surfaced" in x for x in messages))

    def _sm86_payload(self):
        return {
            "dxgi.dll": b"optiscaler-proxy-v1",
            "OptiScaler.ini": b"[Menu]\nOverlayMenu=true\n",
            "OptiScaler/core.dll": b"core-v1",
            "OptiScaler/dlssg_sm86/dlssg_sm86.dll": b"sm86-v1",
            "OptiScaler/dlssg_sm86/dlssg_sm86.ini": b"[x]\n",
            "OptiScaler/streamline/sl.interposer.dll": b"streamline-v1",
            "OptiScaler/streamline/sl.dlss_g.dll": b"dlssg-v1",
            "Licenses/LICENSE.txt": b"fixture-license",
            "nvngx.dll_dlssnr.dll": b"nr-alias-v1",
            "nvngx_dlssnr.dll": b"nr-v1",
        }

    def _steam_localconfig(self, launch_value=None):
        steam_root = self.base / "Steam"
        config = steam_root / "userdata" / "42" / "config" / "localconfig.vdf"
        config.parent.mkdir(parents=True, exist_ok=True)
        launch = ""
        if launch_value is not None:
            launch = f'\t\t\t\t\t\t"LaunchOptions"\t\t"{launch_value}"\n'
        config.write_text(
            '"UserLocalConfigStore"\n{\n'
            '\t"Software"\n\t{\n'
            '\t\t"Valve"\n\t\t{\n'
            '\t\t\t"Steam"\n\t\t\t{\n'
            '\t\t\t\t"apps"\n\t\t\t\t{\n'
            '\t\t\t\t\t"123"\n\t\t\t\t\t{\n'
            + launch +
            '\t\t\t\t\t}\n'
            '\t\t\t\t}\n'
            '\t\t\t}\n'
            '\t\t}\n'
            '\t}\n'
            '}\n',
            encoding="utf-8",
        )
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)
        return config

    def test_localconfig_restore_can_remove_launchoptions_exactly(self):
        config = self._steam_localconfig(None)
        original_bytes = config.read_bytes()
        before = self.m.update_localconfig_launch_options(config, {"123": "FOO=1 %command%"})
        self.assertIsNone(before["123"])
        self.assertEqual(self.m.read_localconfig_launch_options(config, "123"), "FOO=1 %command%")
        self.m.update_localconfig_launch_options(config, {"123": None})
        self.assertIsNone(self.m.read_localconfig_launch_options(config, "123"))
        # Whitespace can differ, but the LaunchOptions key must be truly absent.
        self.assertNotIn('"LaunchOptions"', config.read_text(encoding="utf-8"))
        self.assertTrue(original_bytes)

    def test_interrupted_steam_transaction_rolls_config_and_baseline_metadata_back(self):
        config = self._steam_localconfig("MANGOHUD=1 %command%")
        previous_record = {
            "kind": "steam", "appid": "123", "original": None,
            "applied": "MANGOHUD=1 %command%", "config_path": str(config),
            "steam_userid": "42",
        }
        self._baseline(steam_launch=previous_record)
        file_backup = self.m.backup_steam_config(config, "42")
        new_record = {
            "kind": "steam", "appid": "123", "original": None,
            "applied": "MANGOHUD=1 PROTON_ENABLE_NVAPI=1 %command%",
            "config_path": str(config), "steam_userid": "42",
        }
        entries = [{
            "game": "Fixture", "target_dir": str(self.target), "appid": "123",
            "before": "MANGOHUD=1 %command%",
            "previous_steam_launch": previous_record,
            "new_record": new_record,
        }]
        tx_path, tx = self.m.begin_steam_transaction("steam", config, "42", file_backup, entries)
        self.m.update_localconfig_launch_options(config, {"123": new_record["applied"]})
        tx["phase"] = "config_written"
        self.m.update_steam_transaction(tx_path, tx)
        baseline = self.m.load_baseline(self.target)
        baseline["steam_launch"] = new_record
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        result = self.m.rollback_steam_transaction(tx_path, tx)
        self.assertEqual(result["status"], "rolled_back")
        self.assertEqual(self.m.read_localconfig_launch_options(config, "123"), "MANGOHUD=1 %command%")
        restored = self.m.load_baseline(self.target)
        self.assertEqual(restored["steam_launch"], previous_record)
        self.assertFalse(tx_path.exists())

    def test_restore_batch_commit_marker_prevents_partial_rollback_during_cleanup_crash(self):
        config = self._steam_localconfig("BEFORE %command%")
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        self._baseline()
        backup = self.m.backup_steam_config(config, "42")
        entries = [{
            "game": "Fixture", "target_dir": str(self.target), "appid": "123",
            "before": "BEFORE %command%", "desired": "ORIGINAL %command%",
            "previous_steam_launch": None,
        }]
        tx_path, tx = self.m.begin_steam_transaction("steam", config, "42", backup, entries)
        marker = self.m._steam_batch_commit_marker("fixture-commit").resolve(strict=False)
        tx["batch_commit_marker"] = str(marker)
        self.m.update_steam_transaction(tx_path, tx, phase="config_written")
        self.m.update_localconfig_launch_options(config, {"123": "ORIGINAL %command%"})
        self.m.atomic_write(marker, b"rtxEngine Steam restore batch committed\n", 0o600)

        rows = self.m.recover_pending_steam_transactions(assume_yes=True)
        self.assertEqual(rows[0]["status"], "commit-cleanup-completed")
        self.assertEqual(self.m.read_localconfig_launch_options(config, "123"), "ORIGINAL %command%")
        self.assertFalse(tx_path.exists())
        self.assertFalse(marker.exists())

    def test_orphan_batch_commit_marker_is_cleaned_when_no_journals_remain(self):
        root = self.m._steam_transaction_root()
        root.mkdir(parents=True)
        marker = self.m._steam_batch_commit_marker("orphan-after-cleanup")
        self.m.atomic_write(marker, b"committed\n", 0o600)
        self.assertTrue(marker.is_file())
        rows = self.m.recover_pending_steam_transactions(assume_yes=True)
        self.assertEqual(rows, [])
        self.assertFalse(marker.exists())

    def test_restore_batch_commit_marker_path_escape_is_rejected(self):
        config = self._steam_localconfig("BEFORE %command%")
        backup = self.m.backup_steam_config(config, "42")
        entries = [{
            "game": "Fixture", "target_dir": str(self.target), "appid": "123",
            "before": "BEFORE %command%", "desired": "ORIGINAL %command%",
            "previous_steam_launch": None,
        }]
        tx_path, tx = self.m.begin_steam_transaction("steam", config, "42", backup, entries)
        tx["batch_commit_marker"] = str((self.base / "outside.commit").resolve())
        self.m.update_steam_transaction(tx_path, tx, phase="config_written")
        with self.assertRaises(self.m.Stop):
            self.m.recover_pending_steam_transactions(assume_yes=True)
        self.assertTrue(tx_path.exists())

    def test_prepared_transaction_with_absent_original_is_idempotently_recoverable(self):
        config = self._steam_localconfig(None)
        self._baseline()
        backup = self.m.backup_steam_config(config, "42")
        entries = [{
            "game": "Fixture", "target_dir": str(self.target), "appid": "123",
            "before": None, "previous_steam_launch": None,
            "new_record": {"kind": "steam", "appid": "123", "original": None},
        }]
        tx_path, tx = self.m.begin_steam_transaction("steam", config, "42", backup, entries)
        # Simulate crash before the config write. Recovery should remain a no-op.
        self.m.rollback_steam_transaction(tx_path, tx)
        self.assertIsNone(self.m.read_localconfig_launch_options(config, "123"))
        self.assertFalse(tx_path.exists())


    def test_steam_backup_pruning_preserves_generation_referenced_by_live_transaction(self):
        backup_root = self.m.STATE_ROOT / "steam-config-backups"
        old = backup_root / "old" / "123"
        middle = backup_root / "middle" / "123"
        newest = backup_root / "newest" / "123"
        for directory, stamp in ((old, 1), (middle, 2), (newest, 3)):
            directory.mkdir(parents=True)
            (directory / "localconfig.vdf").write_text(directory.parent.name, encoding="utf-8")
            os.utime(directory.parent, ns=(stamp, stamp))

        tx_root = self.m.STATE_ROOT / "steam-transactions"
        tx_root.mkdir(parents=True)
        self.m.save_json_atomic(tx_root / "active.json", {
            "schema": 1,
            "file_backup": str(old / "localconfig.vdf"),
        })

        self.m.prune_steam_config_backups(keep=1)
        self.assertTrue(old.parent.is_dir(), "active transaction backup generation must survive")
        self.assertFalse(middle.parent.exists())
        self.assertTrue(newest.parent.is_dir())

    def test_corrupt_steam_transaction_disables_backup_pruning_fail_safe(self):
        backup_root = self.m.STATE_ROOT / "steam-config-backups"
        generations = []
        for index in range(3):
            generation = backup_root / f"g{index}"
            generation.mkdir(parents=True)
            generations.append(generation)
        tx_root = self.m.STATE_ROOT / "steam-transactions"
        tx_root.mkdir(parents=True)
        (tx_root / "broken.json").write_text("{not-json", encoding="utf-8")

        self.m.prune_steam_config_backups(keep=1)
        self.assertTrue(all(path.is_dir() for path in generations))


    def test_corrupt_loginusers_metadata_is_surfaced_not_silently_absent(self):
        steam_root = self.base / "SteamLoginMetadata"
        config = steam_root / "config"
        config.mkdir(parents=True)
        (config / "loginusers.vdf").write_text('"users"\n{\n"broken"', encoding="utf-8")
        warnings = []
        with patch.object(self.m, "warn", side_effect=warnings.append):
            recent = self.m._most_recent_account_ids(steam_root)
        self.assertEqual(recent, set())
        self.assertTrue(warnings)
        self.assertIn("MostRecent account metadata", warnings[0])

    def test_noninteractive_steam_account_tie_refuses_to_guess(self):
        steam_root = self.base / "SteamAccounts"
        for userid in ("111", "222"):
            config = steam_root / "userdata" / userid / "config"
            config.mkdir(parents=True)
            (config / "localconfig.vdf").write_text(
                '"UserLocalConfigStore"\n{\n"Software"\n{\n"Valve"\n{\n"Steam"\n{\n"apps"\n{\n"123"\n{\n}\n}\n}\n}\n}\n}\n',
                encoding="utf-8",
            )
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)

        with self.assertRaises(self.m.Stop) as cm:
            self.m.choose_steam_user_config([self.game], assume_yes=True)
        self.assertIn("equally plausible", str(cm.exception))

    def test_full_steam_sync_commits_transaction_and_leaves_no_journal(self):
        config = self._steam_localconfig(None)
        baseline = self._baseline(current={
            "installed_hashes": {},
            "launch_options": 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 %command%',
        })
        shortcuts = config.parent / "shortcuts.vdf"
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        self.m.choose_steam_user_config = lambda games, assume_yes=False: {
            "localconfig": config, "shortcuts": shortcuts, "userid": "42",
            "root": self.m.STEAM_ROOT_CANDIDATES[0], "score": 1,
        }
        result = self.m.sync_launch_options_batch([self.game], assume_yes=True, prompt=False)
        self.assertEqual(result[0]["status"], "written")
        applied = self.m.read_localconfig_launch_options(config, "123")
        self.assertIn("WINEDLLOVERRIDES", applied)
        reloaded = self.m.load_baseline(self.target)
        self.assertIsNone(reloaded["steam_launch"]["original"])
        self.assertEqual(reloaded["steam_launch"]["applied"], applied)
        self.assertEqual(self.m.load_pending_steam_transactions(), [])

    def test_full_steam_sync_repairs_rc2_legacy_nvcuda_in_place(self):
        config = self._steam_localconfig(None)
        self.m.update_localconfig_launch_options(config, {"123": (
            'PROTON_NVIDIA_NVCUDA=1 WINEDLLOVERRIDES="dwmapi=n,b" MANGOHUD=1 %command% -dx12'
        )})
        self._baseline(current={
            "installed_hashes": {},
            # Simulate an RC2 baseline that still requests the legacy variable.
            "launch_options": (
                'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 '
                'PROTON_NVIDIA_NVCUDA=1 %command%'
            ),
        })
        shortcuts = config.parent / "shortcuts.vdf"
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        self.m.choose_steam_user_config = lambda games, assume_yes=False: {
            "localconfig": config, "shortcuts": shortcuts, "userid": "42",
            "root": self.m.STEAM_ROOT_CANDIDATES[0], "score": 1,
        }

        rows = self.m.sync_launch_options_batch([self.game], assume_yes=True, prompt=False)
        self.assertEqual(rows[0]["status"], "written")
        applied = self.m.read_localconfig_launch_options(config, "123")
        self.assertNotIn("PROTON_NVIDIA_NVCUDA", applied)
        self.assertIn('WINEDLLOVERRIDES="dwmapi=n,b;dxgi=n,b"', applied)
        self.assertIn("MANGOHUD=1 %command% -dx12", applied)

    def test_full_steam_sync_failure_after_config_write_rolls_back_automatically(self):
        config = self._steam_localconfig("MANGOHUD=1 %command%")
        self._baseline(current={
            "installed_hashes": {},
            "launch_options": 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 %command%',
        })
        shortcuts = config.parent / "shortcuts.vdf"
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        self.m.choose_steam_user_config = lambda games, assume_yes=False: {
            "localconfig": config, "shortcuts": shortcuts, "userid": "42",
            "root": self.m.STEAM_ROOT_CANDIDATES[0], "score": 1,
        }
        original_save = self.m.save_json_atomic
        baseline_path = self.m.baseline_path(self.target)
        failed = {"done": False}

        def flaky_save(path, data):
            if path == baseline_path and isinstance(data, dict) and "steam_launch" in data and not failed["done"]:
                failed["done"] = True
                raise OSError("simulated baseline commit failure")
            return original_save(path, data)

        self.m.save_json_atomic = flaky_save
        with self.assertRaises(self.m.Stop):
            self.m.sync_launch_options_batch([self.game], assume_yes=True, prompt=False)
        self.assertEqual(self.m.read_localconfig_launch_options(config, "123"), "MANGOHUD=1 %command%")
        self.assertEqual(self.m.load_pending_steam_transactions(), [])
        reloaded = self.m.load_baseline(self.target)
        self.assertNotIn("steam_launch", reloaded)

    def test_dlss_unlocked_trust_follows_pinned_hash_not_filename(self):
        archive = self.base / "renamed-provider.zip"
        import zipfile
        members = {
            "dxgi.dll": b"dxgi",
            "OptiScaler.ini": b"[x]",
            "nvngx.dll_dlssnr.dll": b"nr1",
            "nvngx_dlssnr.dll": b"nr2",
            "OptiScaler/dlssg_sm86/dlssg_sm86.dll": b"sm86",
            "OptiScaler/dlssg_sm86/dlssg_sm86.ini": b"ini",
            "OptiScaler/streamline/sl.interposer.dll": b"sl1",
            "OptiScaler/streamline/sl.dlss_g.dll": b"sl2",
            "Licenses/LICENSE.txt": b"license",
        }
        with zipfile.ZipFile(archive, "w") as zf:
            for name, data in members.items():
                zf.writestr(name, data)
        digest = self.m.sha256_file(archive)
        self.m.KNOWN_ARCHIVES = {
            "official-name.zip": {"sha256": digest, "tag": "fixture-v1"}
        }
        meta = self.m.validate_archive(archive)
        self.assertEqual(meta["known_tag"], "fixture-v1")
        self.assertEqual(meta["canonical_name"], "official-name.zip")

        # Still a valid ZIP after trailing data, but no longer the pinned bytes.
        with archive.open("ab") as f:
            f.write(b"modified")
        with self.assertRaises(self.m.Stop):
            self.m.validate_archive(archive)

    def test_persisted_steam_config_path_outside_userdata_is_rejected(self):
        bad_config = self.base / "not-steam" / "localconfig.vdf"
        bad_config.parent.mkdir()
        bad_config.write_text("x", encoding="utf-8")
        steam_root = self.base / "Steam"
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)
        b = self._baseline(steam_launch={
            "kind": "steam", "config_path": str(bad_config), "steam_userid": "42",
            "appid": "123", "original": None, "applied": "X=1 %command%",
        })
        with self.assertRaises(self.m.Stop):
            self.m.verify_baseline_integrity(self.target, b, adopt_legacy=False)

    def test_final_artifact_has_no_duplicate_defs_or_unresolved_user_globals(self):
        import ast
        import builtins
        import dis
        import inspect
        import types

        tree = ast.parse(SCRIPT.read_text(encoding="utf-8"))
        seen = {}
        duplicates = []
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if node.name in seen:
                    duplicates.append((node.name, seen[node.name], node.lineno))
                seen[node.name] = node.lineno
        self.assertEqual(duplicates, [])

        allowed = set(vars(self.m)) | set(dir(builtins))
        unresolved = set()

        def scan(code, owner):
            if Path(code.co_filename).resolve() != SCRIPT.resolve():
                return
            for ins in dis.get_instructions(code):
                if ins.opname in {"LOAD_GLOBAL", "LOAD_NAME"} and isinstance(ins.argval, str):
                    if ins.argval not in allowed:
                        unresolved.add((owner, ins.argval))
            for const in code.co_consts:
                if isinstance(const, types.CodeType):
                    scan(const, owner + "::<nested>")

        for name, obj in vars(self.m).items():
            if getattr(obj, "__module__", None) != self.m.__name__:
                continue
            if inspect.isfunction(obj):
                scan(obj.__code__, name)
            elif inspect.isclass(obj):
                for method_name, method in vars(obj).items():
                    if inspect.isfunction(method):
                        scan(method.__code__, f"{name}.{method_name}")
        self.assertEqual(sorted(unresolved), [])

    def test_interrupted_fresh_install_persists_full_cleanup_plan_before_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "9" * 64, "known_tag": "fixture"}
        real_atomic = self.m.atomic_write
        fail_path = self.target / "nvngx.dll_dlssnr.dll"

        def fail_after_first_root_write(path, data, mode=0o644):
            path = Path(path)
            if path == fail_path:
                raise OSError("simulated mid-install root write failure")
            return real_atomic(path, data, mode)

        self.m.atomic_write = fail_after_first_root_write
        with self.assertRaises(OSError):
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")

        # dxgi sorts before the injected failure and proves live mutation began.
        self.assertTrue((self.target / "dxgi.dll").is_file())
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["status"], "interrupted")
        self.assertIn("dxgi.dll", baseline["managed_paths"])
        self.assertIn("OptiScaler.ini", baseline["managed_paths"])
        self.assertIn("pending_install", baseline)
        self.assertEqual(
            baseline["pending_install"]["installed_hashes"]["dxgi.dll"],
            self.m.sha256_file(self.target / "dxgi.dll"),
        )

        restored = self.m.restore_target(self.game)
        self.assertFalse((self.target / "dxgi.dll").exists())
        self.assertFalse((self.target / "OptiScaler.ini").exists())
        self.assertFalse((self.target / "nvngx.dll_dlssnr.dll").exists())
        recovery = Path(restored["recovery"])
        self.assertFalse((recovery / "dxgi.dll").exists(), "known partial engine bytes should not bloat recovery")

    def test_fresh_install_refresh_restore_reinstall_lifecycle(self):
        # Exercise the core reversible transaction model without the Ada MFG
        # provider so this fixture stays dependency-free.
        self.game.dlss = True
        self.game.dlssg = True
        original_proxy = self.target / "dxgi.dll"
        write_minimal_pe(self.exe, ["version.dll"])
        original_proxy.write_bytes(b"original-game-proxy")
        old_opti = self.target / "OptiScaler"
        old_opti.mkdir()
        (old_opti / "old.txt").write_text("original tree", encoding="utf-8")

        payload = self._sm86_payload()
        archive_meta = {"name": "fixture.zip", "sha256": "a" * 64, "known_tag": "fixture"}

        first = self.m.install_target(self.game, payload, archive_meta, "sm86")
        self.assertEqual(first["gpu_family"], "sm86")
        self.assertEqual(first["proxy"], "version.dll")
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["status"], "active")
        self.m.verify_baseline_integrity(self.target, baseline, adopt_legacy=False)
        self.assertEqual(original_proxy.read_bytes(), b"original-game-proxy")
        self.assertTrue((self.target / "version.dll").is_file())

        # Refresh the active install to exercise existing-baseline verification.
        second = self.m.install_target(self.game, payload, archive_meta, "sm86")
        self.assertEqual(second["gpu_family"], "sm86")

        restored = self.m.restore_target(self.game)
        archived_state = Path(restored["archived_state"])
        self.assertTrue(archived_state.is_file())
        receipt = json.loads(archived_state.read_text(encoding="utf-8"))
        self.assertFalse(receipt["baseline_payload_retained"])
        self.assertFalse((self.m.state_dir_for(self.target) / "baseline-backup").exists())
        self.assertFalse(list(self.m.state_dir_for(self.target).glob("baseline-backup-restored-*")))
        self.assertGreater(restored["discarded_backup_bytes"], 0)
        for info in receipt["originals"].values():
            if isinstance(info, dict):
                self.assertNotIn("backup", info)
        self.assertEqual(original_proxy.read_bytes(), b"original-game-proxy")
        self.assertEqual((old_opti / "old.txt").read_text(encoding="utf-8"), "original tree")
        self.assertFalse(self.m.baseline_path(self.target).exists())

        third = self.m.install_target(self.game, payload, archive_meta, "sm86")
        self.assertEqual(third["gpu_family"], "sm86")
        self.assertEqual(third["proxy"], "version.dll")
        self.assertEqual(original_proxy.read_bytes(), b"original-game-proxy")
        self.assertTrue(self.m.baseline_path(self.target).is_file())

    def test_reshade_coexistence_uses_version_proxy_and_preserves_reshade(self):
        self.game.dlss = True
        self.game.dlssg = True
        reshade_bytes = b"ReShade injected proxy fixture"
        (self.target / "dxgi.dll").write_bytes(reshade_bytes)
        (self.target / "ReShade.ini").write_text("[GENERAL]\n", encoding="utf-8")
        archive_meta = {"name": "fixture.zip", "sha256": "b" * 64, "known_tag": "fixture"}

        record = self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual(record["proxy"], "version.dll")
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), reshade_bytes)
        self.assertTrue((self.target / "version.dll").is_file())

        self.m.restore_target(self.game)
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), reshade_bytes)
        self.assertFalse((self.target / "version.dll").exists())


    def test_repeated_external_adoption_prunes_superseded_payload_after_commit(self):
        live = self.target / "dxgi.dll"
        live.write_bytes(b"external-one")
        baseline = self._baseline(
            originals={"dxgi.dll": {"kind": "file", "existed": False}},
            managed_paths=["dxgi.dll"],
        )
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        baseline = self.m.adopt_external_file_as_original(baseline, self.target, "dxgi.dll")
        first = Path(baseline["originals"]["dxgi.dll"]["backup"])
        self.assertTrue(first.is_file())
        self.assertEqual(first.read_bytes(), b"external-one")

        live.write_bytes(b"external-two")
        baseline = self.m.adopt_external_file_as_original(baseline, self.target, "dxgi.dll")
        second = Path(baseline["originals"]["dxgi.dll"]["backup"])
        self.assertTrue(second.is_file())
        self.assertEqual(second.read_bytes(), b"external-two")
        self.assertNotEqual(first, second)
        self.assertFalse(first.exists())

    def test_refresh_refuses_externally_changed_managed_root_payload(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "b" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        nr = self.target / "nvngx_dlssnr.dll"
        nr.write_bytes(b"external-owner")
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertIn("Managed payload file changed externally", str(cm.exception))
        self.assertEqual(nr.read_bytes(), b"external-owner")
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["status"], "active")

    def test_interrupted_refresh_accepts_root_payload_matching_pending_install_hash(self):
        self.game.dlss = True
        self.game.dlssg = True
        first_meta = {"name": "fixture.zip", "sha256": "a" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), first_meta, "sm86")
        payload2 = self._sm86_payload()
        payload2["nvngx_dlssnr.dll"] = b"nr-v2"
        nr = self.target / "nvngx_dlssnr.dll"
        nr.write_bytes(payload2["nvngx_dlssnr.dll"])
        baseline = self.m.load_baseline(self.target)
        baseline["status"] = "interrupted"
        baseline["pending_install"] = {
            "started_utc": self.m.now_iso(),
            "archive_sha256": "c" * 64,
            "gpu_family": "sm86",
            "proxy": "dxgi.dll",
            "mfg_proxy": None,
            "installed_hashes": {rel: self.m.sha256_bytes(data) for rel, data in payload2.items()},
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)
        record = self.m.install_target(
            self.game,
            payload2,
            {"name": "fixture2.zip", "sha256": "c" * 64, "known_tag": "fixture2"},
            "sm86",
        )
        self.assertEqual(nr.read_bytes(), b"nr-v2")
        self.assertEqual(record["installed_hashes"]["nvngx_dlssnr.dll"], self.m.sha256_bytes(b"nr-v2"))

    def test_provider_upgrade_relinquishes_preexisting_root_payload(self):
        self.game.dlss = True
        self.game.dlssg = True
        retired = self.target / "retired-provider.dll"
        retired.write_bytes(b"game-original")
        payload1 = self._sm86_payload()
        payload1["retired-provider.dll"] = b"provider-v1"
        meta1 = {"name": "fixture-v1.zip", "sha256": "1" * 64, "known_tag": "fixture-v1"}
        self.m.install_target(self.game, payload1, meta1, "sm86")
        self.assertEqual(retired.read_bytes(), b"provider-v1")

        payload2 = self._sm86_payload()
        meta2 = {"name": "fixture-v2.zip", "sha256": "2" * 64, "known_tag": "fixture-v2"}
        record = self.m.install_target(self.game, payload2, meta2, "sm86")
        self.assertEqual(retired.read_bytes(), b"game-original")
        self.assertEqual(record["provider_paths_relinquished"], ["retired-provider.dll"])

        baseline = self.m.load_baseline(self.target)
        self.assertNotIn("retired-provider.dll", baseline["managed_paths"])
        self.assertNotIn("retired-provider.dll", baseline["originals"])
        self.assertNotIn("retired-provider.dll", baseline["current"]["installed_hashes"])

        self.m.restore_target(self.game)
        self.assertEqual(retired.read_bytes(), b"game-original")

    def test_provider_upgrade_removes_engine_created_root_payload_when_dropped(self):
        self.game.dlss = True
        self.game.dlssg = True
        payload1 = self._sm86_payload()
        payload1["retired-provider.dll"] = b"provider-v1"
        meta1 = {"name": "fixture-v1.zip", "sha256": "3" * 64, "known_tag": "fixture-v1"}
        self.m.install_target(self.game, payload1, meta1, "sm86")
        retired = self.target / "retired-provider.dll"
        self.assertTrue(retired.is_file())

        record = self.m.install_target(
            self.game,
            self._sm86_payload(),
            {"name": "fixture-v2.zip", "sha256": "4" * 64, "known_tag": "fixture-v2"},
            "sm86",
        )
        self.assertFalse(retired.exists())
        self.assertEqual(record["provider_paths_relinquished"], ["retired-provider.dll"])
        baseline = self.m.load_baseline(self.target)
        self.assertNotIn("retired-provider.dll", baseline["managed_paths"])
        self.assertNotIn("retired-provider.dll", baseline["originals"])

        self.m.restore_target(self.game)
        self.assertFalse(retired.exists())

    def test_provider_upgrade_relinquishment_refuses_external_drift_before_state_change(self):
        self.game.dlss = True
        self.game.dlssg = True
        payload1 = self._sm86_payload()
        payload1["retired-provider.dll"] = b"provider-v1"
        meta1 = {"name": "fixture-v1.zip", "sha256": "5" * 64, "known_tag": "fixture-v1"}
        self.m.install_target(self.game, payload1, meta1, "sm86")
        retired = self.target / "retired-provider.dll"
        retired.write_bytes(b"external-owner")

        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(
                self.game,
                self._sm86_payload(),
                {"name": "fixture-v2.zip", "sha256": "6" * 64, "known_tag": "fixture-v2"},
                "sm86",
            )
        self.assertIn("refusing ownership transfer", str(cm.exception))
        self.assertEqual(retired.read_bytes(), b"external-owner")
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["status"], "active")
        self.assertNotIn("provider_relinquish", baseline)
        self.assertIn("retired-provider.dll", baseline["managed_paths"])

    def test_provider_relinquishment_retry_after_restore_crash_is_idempotent(self):
        self.game.dlss = True
        self.game.dlssg = True
        retired = self.target / "retired-provider.dll"
        retired.write_bytes(b"game-original")
        payload1 = self._sm86_payload()
        payload1["retired-provider.dll"] = b"provider-v1"
        self.m.install_target(
            self.game, payload1,
            {"name": "fixture-v1.zip", "sha256": "7" * 64, "known_tag": "fixture-v1"},
            "sm86",
        )
        meta2 = {"name": "fixture-v2.zip", "sha256": "8" * 64, "known_tag": "fixture-v2"}

        real_save = self.m.save_json_atomic
        failed = {"done": False}
        def fail_first_applied_commit(path, data):
            plan = data.get("provider_relinquish") if isinstance(data, dict) else None
            entries = (plan or {}).get("paths", {}) if isinstance(plan, dict) else {}
            if (
                not failed["done"]
                and any(isinstance(entry, dict) and entry.get("phase") == "applied" for entry in entries.values())
            ):
                failed["done"] = True
                raise OSError("simulated crash after original restore")
            return real_save(path, data)

        self.m.save_json_atomic = fail_first_applied_commit
        try:
            with self.assertRaises(OSError):
                self.m.install_target(self.game, self._sm86_payload(), meta2, "sm86")
        finally:
            self.m.save_json_atomic = real_save

        self.assertEqual(retired.read_bytes(), b"game-original")
        interrupted = self.m.load_baseline(self.target)
        self.assertEqual(interrupted["status"], "applying")
        self.assertIn("provider_relinquish", interrupted)
        self.assertEqual(
            interrupted["provider_relinquish"]["paths"]["retired-provider.dll"]["phase"],
            "pending",
        )

        record = self.m.install_target(self.game, self._sm86_payload(), meta2, "sm86")
        self.assertEqual(record["provider_paths_relinquished"], ["retired-provider.dll"])
        self.assertEqual(retired.read_bytes(), b"game-original")
        final = self.m.load_baseline(self.target)
        self.assertEqual(final["status"], "active")
        self.assertNotIn("provider_relinquish", final)
        self.assertNotIn("retired-provider.dll", final["managed_paths"])

    def test_provider_relinquishment_retry_after_remove_crash_is_idempotent(self):
        self.game.dlss = True
        self.game.dlssg = True
        payload1 = self._sm86_payload()
        payload1["retired-provider.dll"] = b"provider-v1"
        self.m.install_target(
            self.game, payload1,
            {"name": "fixture-v1.zip", "sha256": "9" * 64, "known_tag": "fixture-v1"},
            "sm86",
        )
        retired = self.target / "retired-provider.dll"
        meta2 = {"name": "fixture-v2.zip", "sha256": "a" * 64, "known_tag": "fixture-v2"}

        real_save = self.m.save_json_atomic
        failed = {"done": False}
        def fail_first_applied_commit(path, data):
            plan = data.get("provider_relinquish") if isinstance(data, dict) else None
            entries = (plan or {}).get("paths", {}) if isinstance(plan, dict) else {}
            if (
                not failed["done"]
                and any(isinstance(entry, dict) and entry.get("phase") == "applied" for entry in entries.values())
            ):
                failed["done"] = True
                raise OSError("simulated crash after engine file removal")
            return real_save(path, data)

        self.m.save_json_atomic = fail_first_applied_commit
        try:
            with self.assertRaises(OSError):
                self.m.install_target(self.game, self._sm86_payload(), meta2, "sm86")
        finally:
            self.m.save_json_atomic = real_save

        self.assertFalse(retired.exists())
        interrupted = self.m.load_baseline(self.target)
        self.assertIn("provider_relinquish", interrupted)
        self.m.install_target(self.game, self._sm86_payload(), meta2, "sm86")
        self.assertFalse(retired.exists())
        final = self.m.load_baseline(self.target)
        self.assertEqual(final["status"], "active")
        self.assertNotIn("provider_relinquish", final)
        self.assertNotIn("retired-provider.dll", final["managed_paths"])

    def test_provider_relinquishment_pending_different_provider_is_refused(self):
        self.game.dlss = True
        self.game.dlssg = True
        payload1 = self._sm86_payload()
        payload1["retired-provider.dll"] = b"provider-v1"
        self.m.install_target(
            self.game, payload1,
            {"name": "fixture-v1.zip", "sha256": "b" * 64, "known_tag": "fixture-v1"},
            "sm86",
        )
        meta2 = {"name": "fixture-v2.zip", "sha256": "c" * 64, "known_tag": "fixture-v2"}

        real_save = self.m.save_json_atomic
        failed = {"done": False}
        def fail_after_plan(path, data):
            plan = data.get("provider_relinquish") if isinstance(data, dict) else None
            if plan and not failed["done"]:
                failed["done"] = True
                real_save(path, data)
                raise OSError("simulated stop after relinquishment plan commit")
            return real_save(path, data)

        self.m.save_json_atomic = fail_after_plan
        try:
            with self.assertRaises(OSError):
                self.m.install_target(self.game, self._sm86_payload(), meta2, "sm86")
        finally:
            self.m.save_json_atomic = real_save

        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(
                self.game,
                self._sm86_payload(),
                {"name": "fixture-v3.zip", "sha256": "d" * 64, "known_tag": "fixture-v3"},
                "sm86",
            )
        self.assertIn("different provider bytes", str(cm.exception))
        pending = self.m.load_baseline(self.target)
        self.assertIn("provider_relinquish", pending)
        self.assertEqual(pending["provider_relinquish"]["archive_sha256"], "c" * 64)

    def test_corrupt_provider_relinquishment_state_fails_closed(self):
        retired = self.target / "retired-provider.dll"
        retired.write_bytes(b"provider-v1")
        backup = self.m.state_dir_for(self.target) / "baseline-backup" / "files" / "retired-provider.dll"
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_bytes(b"game-original")
        baseline = self._baseline(
            status="applying",
            originals={
                "retired-provider.dll": {
                    "kind": "file", "existed": True, "backup": str(backup),
                    "sha256": self.m.sha256_bytes(b"game-original"), "mode": 0o644,
                }
            },
            managed_paths=["retired-provider.dll"],
            current={"installed_hashes": {"retired-provider.dll": self.m.sha256_bytes(b"provider-v1")}},
            provider_relinquish={
                "started_utc": self.m.now_iso(),
                "archive_sha256": "e" * 64,
                "paths": {
                    "retired-provider.dll": {
                        "action": "restore-original",
                        "phase": "pending",
                        "engine_hashes": [self.m.sha256_bytes(b"provider-v1")],
                        "original_key": "wrong-name.dll",
                        "original_sha256": self.m.sha256_bytes(b"game-original"),
                    }
                },
            },
        )
        with self.assertRaises(self.m.Stop) as cm:
            self.m.verify_baseline_integrity(self.target, baseline, adopt_legacy=False)
        self.assertIn("original key mismatch", str(cm.exception))
        self.assertEqual(retired.read_bytes(), b"provider-v1")

    def test_refresh_preserves_user_modified_optiscaler_ini_then_reasserts_policy(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "c" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        ini = self.target / "OptiScaler.ini"
        ini.write_text(
            ini.read_text(encoding="utf-8") + "\n[UserPrefs]\nRenderScale=0.70\nKeepMe=yes\n",
            encoding="utf-8",
        )

        refreshed = self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        text = ini.read_text(encoding="utf-8")
        self.assertIn("[UserPrefs]", text)
        self.assertIn("RenderScale=0.70", text)
        self.assertIn("KeepMe=yes", text)
        self.assertIn("AmpereMfgUnlock=true", text)
        self.assertEqual(self.m.sha256_file(ini), refreshed["installed_hashes"]["OptiScaler.ini"])

    def test_refresh_refuses_unexpected_or_modified_file_inside_managed_optiscaler_tree(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "d" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        unexpected = self.target / "OptiScaler" / "user-addon.dll"
        unexpected.write_bytes(b"do-not-delete")
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertIn("Unexpected file inside managed OptiScaler tree", str(cm.exception))
        self.assertEqual(unexpected.read_bytes(), b"do-not-delete")

        unexpected.unlink()
        managed = self.target / "OptiScaler" / "core.dll"
        managed.write_bytes(b"external-change")
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertIn("changed externally", str(cm.exception))
        self.assertEqual(managed.read_bytes(), b"external-change")

    def test_interrupted_first_install_can_resume_when_original_optiscaler_tree_matches_backed_baseline(self):
        self.game.dlss = True
        self.game.dlssg = True
        old_tree = self.target / "OptiScaler"
        old_tree.mkdir()
        (old_tree / "legacy.dll").write_bytes(b"legacy-original")
        payload = self._sm86_payload()
        baseline = self.m.create_baseline(self.game, set(payload), "dxgi.dll", [])
        baseline["status"] = "interrupted"
        baseline["managed_paths"] = sorted(set(payload) | {"OptiScaler/"}, key=str.casefold)
        baseline["pending_install"] = {
            "started_utc": self.m.now_iso(),
            "archive_sha256": "e" * 64,
            "gpu_family": "sm86",
            "proxy": "dxgi.dll",
            "mfg_proxy": None,
            "installed_hashes": {rel: self.m.sha256_bytes(data) for rel, data in payload.items()},
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        record = self.m.install_target(
            self.game,
            payload,
            {"name": "fixture.zip", "sha256": "e" * 64, "known_tag": "fixture"},
            "sm86",
        )
        self.assertEqual(record["proxy"], "dxgi.dll")
        self.assertFalse((old_tree / "legacy.dll").exists())
        self.m.restore_target(self.game)
        self.assertEqual((old_tree / "legacy.dll").read_bytes(), b"legacy-original")

    def test_late_reshade_external_replacement_is_adopted_not_deleted(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "c" * 64, "known_tag": "fixture"}
        first = self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual(first["proxy"], "dxgi.dll")

        late_reshade = b"ReShade late external replacement"
        (self.target / "dxgi.dll").write_bytes(late_reshade)
        (self.target / "ReShade.ini").write_text("[GENERAL]\n", encoding="utf-8")
        refreshed = self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual(refreshed["proxy"], "version.dll")
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), late_reshade)

        self.m.restore_target(self.game)
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), late_reshade)

    def test_refresh_refuses_optiscaler_filesystem_hazard_before_tree_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        meta = {"name": "fixture.zip", "sha256": "8" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), meta, "sm86")
        core = self.target / "OptiScaler" / "core.dll"
        before = core.read_bytes()
        real = self.m._pristine_tree_hazards
        opti = (self.target / "OptiScaler").resolve()
        self.m._pristine_tree_hazards = lambda p: [f"nested mount point: {p}/mounted"] if Path(p).resolve() == opti else real(p)
        try:
            with self.assertRaises(self.m.Stop) as cm:
                self.m.install_target(self.game, self._sm86_payload(), meta, "sm86")
        finally:
            self.m._pristine_tree_hazards = real
        self.assertIn("unsafe filesystem boundary", str(cm.exception))
        self.assertEqual(core.read_bytes(), before)

    def test_restore_refuses_optiscaler_filesystem_hazard_before_tree_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        meta = {"name": "fixture.zip", "sha256": "9" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), meta, "sm86")
        core = self.target / "OptiScaler" / "core.dll"
        before = core.read_bytes()
        real = self.m._pristine_tree_hazards
        opti = (self.target / "OptiScaler").resolve()
        self.m._pristine_tree_hazards = lambda p: [f"special filesystem node: {p}/fifo"] if Path(p).resolve() == opti else real(p)
        try:
            with self.assertRaises(self.m.Stop) as cm:
                self.m.restore_target(self.game)
        finally:
            self.m._pristine_tree_hazards = real
        self.assertIn("unsafe filesystem boundary", str(cm.exception))
        self.assertEqual(core.read_bytes(), before)
        self.assertTrue(self.m.baseline_path(self.target).is_file())

    def test_restore_refuses_managed_file_directory_type_drift_before_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        meta = {"name": "fixture.zip", "sha256": "7" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), meta, "sm86")
        victim = self.target / "nvngx_dlssnr.dll"
        victim.unlink()
        victim.mkdir()
        sentinel = victim / "external.txt"
        sentinel.write_text("keep", encoding="utf-8")
        untouched = self.target / "dxgi.dll"
        before = untouched.read_bytes()

        with self.assertRaises(self.m.Stop) as cm:
            self.m.restore_target(self.game)
        self.assertIn("changed filesystem type externally", str(cm.exception))
        self.assertTrue(sentinel.is_file())
        self.assertEqual(untouched.read_bytes(), before)
        self.assertTrue(self.m.baseline_path(self.target).is_file())

    def test_same_proxy_external_drift_refuses_refresh(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "d" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        (self.target / "dxgi.dll").write_bytes(b"unknown external replacement")
        with self.assertRaises(self.m.Stop):
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), b"unknown external replacement")

    def test_managed_optiscaler_proxy_symlink_type_drift_refuses_refresh(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "e" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        managed = self.target / "dxgi.dll"
        original_bytes = managed.read_bytes()
        outside = self.base / "outside-identical-dxgi.dll"
        outside.write_bytes(original_bytes)
        managed.unlink()
        managed.symlink_to(outside)
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        # Baseline path-containment validation may reject the symlink even
        # earlier than the managed-proxy structural-drift guard. Either way,
        # refresh must fail before replacing/following the link.
        self.assertTrue(
            "filesystem type externally" in str(cm.exception)
            or "Persisted path escapes target" in str(cm.exception)
        )
        self.assertTrue(managed.is_symlink())
        self.assertEqual(outside.read_bytes(), original_bytes)

    def test_shortcuts_binary_patch_and_restore_is_surgical_and_exact(self):
        shortcuts = self.base / "shortcuts.vdf"
        original_launch = 'MANGOHUD=1 gamescope -f %command% -dx12'
        original = make_shortcuts_fixture(self.game, original_launch)
        shortcuts.write_bytes(original)

        expected = 'MANGOHUD=1 WINEDLLOVERRIDES="dxgi=n,b" gamescope -f %command% -dx12'
        result = self.m.patch_shortcuts_launch_options(shortcuts, [(self.game, expected)])
        row = result[self.game.name]
        self.assertEqual(row["status"], "updated")
        self.assertEqual(row["original"], original_launch)

        changed = shortcuts.read_bytes()
        self.assertNotEqual(changed, original)
        parsed = self.m.parse_shortcuts_spans(changed)
        matched = self.m.match_shortcut_span(self.game, parsed)
        self.assertIsNotNone(matched)
        self.assertEqual(self.m._shortcut_string(matched, "LaunchOptions"), expected)
        self.assertEqual(self.m._shortcut_string(matched, "AppName"), self.game.name)
        self.assertIsNotNone(self.m._shortcut_field(matched, "tags"))

        locator = {
            "shortcut_appid": row["shortcut_appid"],
            "shortcut_appname": row["shortcut_appname"],
            "shortcut_exe": row["shortcut_exe"],
        }
        self.m.restore_shortcut_launch_option(shortcuts, locator, original_launch)
        self.assertEqual(shortcuts.read_bytes(), original)

    def test_shortcuts_without_launchoptions_refuses_structural_rewrite(self):
        shortcuts = self.base / "shortcuts.vdf"
        original = make_shortcuts_fixture(self.game, None)
        shortcuts.write_bytes(original)
        result = self.m.patch_shortcuts_launch_options(
            shortcuts, [(self.game, 'WINEDLLOVERRIDES="dxgi=n,b" %command%')]
        )
        self.assertEqual(result[self.game.name]["status"], "unmatched")
        self.assertIn("no existing LaunchOptions", result[self.game.name]["error"])
        self.assertEqual(shortcuts.read_bytes(), original)

    def test_pe_import_parser_and_safe_proxy_selection(self):
        write_minimal_pe(self.exe, ["VERSION.dll", "winmm.dll", "dxgi.dll"])
        self.assertEqual(
            self.m.pe_imported_dlls(self.exe),
            {"version.dll", "winmm.dll", "dxgi.dll"},
        )
        # OptiScaler owns dxgi and an external/game-owned version.dll exists, so
        # RTXMFG must select the next actually imported free proxy.
        (self.target / "version.dll").write_bytes(b"game-owned")
        chosen = self.m.choose_rtxmfg_proxy(self.game, {"dxgi.dll"})
        self.assertEqual(chosen, "winmm.dll")

    def test_rc2_integrated_proxy_prefers_imported_wininet_over_unproven_dxgi(self):
        write_minimal_pe(self.exe, ["wininet.dll"])
        self.game.dlss = True
        self.game.dlssg = True
        runtime, runtime_meta = self.m.load_integrated_ada_runtime()
        archive_meta = {"name": "fixture.zip", "sha256": "a" * 64, "known_tag": "fixture"}
        record = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(record["proxy"], "wininet.dll")
        self.assertIn('WINEDLLOVERRIDES="wininet=n,b"', record["launch_options"])
        self.assertEqual(record["compatibility_policy"]["proxy_imports"], ["wininet.dll"])

    def test_rc2_refresh_migrates_rc1_dxgi_to_positive_import_proxy_safely(self):
        # RC1 fallback: no PE import evidence, so integrated Ada uses dxgi.
        self.game.dlss = True
        self.game.dlssg = True
        runtime, runtime_meta = self.m.load_integrated_ada_runtime()
        archive_meta = {"name": "fixture.zip", "sha256": "d" * 64, "known_tag": "fixture"}
        first = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(first["proxy"], "dxgi.dll")
        self.assertTrue((self.target / "dxgi.dll").is_file())

        # RC2 sees positive wininet import evidence and transactionally moves
        # ownership without leaving the old engine-owned dxgi proxy behind.
        write_minimal_pe(self.exe, ["wininet.dll"])
        refreshed = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(refreshed["proxy"], "wininet.dll")
        self.assertFalse((self.target / "dxgi.dll").exists())
        self.assertEqual((self.target / "wininet.dll").read_bytes(), runtime)

    def test_rc2_preserves_rc1_proxy_when_runtime_log_proves_mfg_applied(self):
        self.game.dlss = True
        self.game.dlssg = True
        runtime, runtime_meta = self.m.load_integrated_ada_runtime()
        archive_meta = {"name": "fixture.zip", "sha256": "e" * 64, "known_tag": "fixture"}
        first = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(first["proxy"], "dxgi.dll")
        (self.target / "OptiScaler.log").write_text(
            "RTXForge.NativeMfgMenu.v3e: applied native interpolation request generation=1\n",
            encoding="utf-8",
        )
        write_minimal_pe(self.exe, ["wininet.dll", "dxgi.dll"])
        refreshed = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(refreshed["proxy"], "dxgi.dll")
        self.assertTrue(refreshed["compatibility_policy"]["preserved_proven_proxy"])

    def test_rc2_reshade_coexistence_prefers_imported_wininet_and_keeps_dxgi_override(self):
        write_minimal_pe(self.exe, ["wininet.dll"])
        self.game.dlss = True
        self.game.dlssg = True
        (self.target / "dxgi.dll").write_bytes(b"ReShade injected proxy fixture")
        (self.target / "ReShade.ini").write_text("[GENERAL]\n", encoding="utf-8")
        runtime, runtime_meta = self.m.load_integrated_ada_runtime()
        archive_meta = {"name": "fixture.zip", "sha256": "b" * 64, "known_tag": "fixture"}
        record = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(record["proxy"], "wininet.dll")
        self.assertIn('WINEDLLOVERRIDES="dxgi=n,b;wininet=n,b"', record["launch_options"])
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), b"ReShade injected proxy fixture")

    def test_ada_no_safe_proxy_refuses_before_baseline_or_game_mutation(self):
        write_minimal_pe(self.exe, ["winmm.dll"])
        self.game.dlss = True
        self.game.dlssg = True
        occupied = self.target / "winmm.dll"
        occupied.write_bytes(b"game-owned-winmm")
        archive_meta = {"name": "fixture.zip", "sha256": "e" * 64, "known_tag": "fixture"}
        with self.assertRaises(self.m.Stop):
            self.m.install_target(
                self.game, self._sm86_payload(), archive_meta, "ada",
                rtxmfg_payload=b"MZ-rtxmfg",
                rtxmfg_meta={"version": "fixture", "sha256": "f" * 64, "dll_sha256": "0" * 64},
            )
        self.assertFalse(self.m.baseline_path(self.target).exists())
        self.assertEqual(occupied.read_bytes(), b"game-owned-winmm")

    def test_ada_refresh_refuses_rtxmfg_proxy_filesystem_type_drift_before_other_mutation(self):
        write_minimal_pe(self.exe, ["winmm.dll", "dinput8.dll"])
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "0" * 64, "known_tag": "fixture"}
        mfg_bytes = b"MZ-rtxmfg"
        mfg_meta = {
            "version": "fixture",
            "sha256": "1" * 64,
            "dll_sha256": self.m.sha256_bytes(mfg_bytes),
        }

        first = self.m.install_target(
            self.game,
            self._sm86_payload(),
            archive_meta,
            "ada",
            rtxmfg_payload=mfg_bytes,
            rtxmfg_meta=mfg_meta,
        )
        self.assertEqual(first["mfg_provider"]["proxy"], "winmm.dll")
        unrelated = self.target / "nvngx_dlssnr.dll"
        unrelated_before = unrelated.read_bytes()

        managed_mfg = self.target / "winmm.dll"
        managed_mfg.unlink()
        managed_mfg.mkdir()
        sentinel = managed_mfg / "external.txt"
        sentinel.write_bytes(b"do-not-touch")

        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(
                self.game,
                self._sm86_payload(),
                archive_meta,
                "ada",
                rtxmfg_payload=mfg_bytes,
                rtxmfg_meta=mfg_meta,
            )
        self.assertIn("Managed RTXMFG proxy changed filesystem type externally", str(cm.exception))
        self.assertTrue(sentinel.is_file())
        self.assertEqual(sentinel.read_bytes(), b"do-not-touch")
        self.assertEqual(unrelated.read_bytes(), unrelated_before)
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["status"], "active")
        self.assertEqual(baseline["current"]["mfg_provider"]["proxy"], "winmm.dll")

    def test_ada_external_mfg_proxy_replacement_moves_to_next_safe_proxy(self):
        write_minimal_pe(self.exe, ["winmm.dll", "dinput8.dll"])
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "1" * 64, "known_tag": "fixture"}
        mfg_meta = {"version": "fixture", "sha256": "2" * 64, "dll_sha256": self.m.sha256_bytes(b"MZ-rtxmfg")}

        first = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            rtxmfg_payload=b"MZ-rtxmfg", rtxmfg_meta=mfg_meta,
        )
        self.assertEqual(first["mfg_provider"]["proxy"], "winmm.dll")
        external = b"external replacement that must survive"
        (self.target / "winmm.dll").write_bytes(external)

        refreshed = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            rtxmfg_payload=b"MZ-rtxmfg", rtxmfg_meta=mfg_meta,
        )
        self.assertEqual(refreshed["mfg_provider"]["proxy"], "dinput8.dll")
        self.assertEqual((self.target / "winmm.dll").read_bytes(), external)

        self.m.restore_target(self.game)
        self.assertEqual((self.target / "winmm.dll").read_bytes(), external)
        self.assertFalse((self.target / "dinput8.dll").exists())



    def test_permission_locked_tree_uses_baseline_fallback_before_live_repair(self):
        self.game.dlss = True
        self.game.dlssg = True
        opti = self.target / "OptiScaler"
        opti.mkdir()
        (opti / "legacy.bin").write_bytes(b"legacy")
        archive_meta = {"name": "fixture.zip", "sha256": "3" * 64, "known_tag": "fixture"}

        real_copytree = self.m.shutil.copytree
        def deny_old_tree(src, dst, *args, **kwargs):
            if Path(src) == opti:
                raise PermissionError("fixture EACCES")
            return real_copytree(src, dst, *args, **kwargs)
        self.m.shutil.copytree = deny_old_tree

        def fake_tar_backup(src, backup_root, name):
            archive = backup_root / "trees" / f"{name}.tar"
            archive.parent.mkdir(parents=True, exist_ok=True)
            with tarfile.open(archive, "w") as tf:
                tf.add(src, arcname=name)
            return {
                "kind": "tar_tree", "existed": True, "backup": str(archive),
                "bytes": archive.stat().st_size, "archive_sha256": self.m.sha256_file(archive),
                "preserves_numeric_owner": True,
            }
        self.m._backup_tree_tar = fake_tar_backup

        repair_seen = []
        def fake_repair(path, label):
            baseline = self.m.load_baseline(self.target)
            self.assertIsNotNone(baseline, "live repair happened before baseline.json existed")
            self.assertEqual(baseline["originals"]["OptiScaler/"]["kind"], "tar_tree")
            repair_seen.append(str(path))
            return True
        self.m.ensure_tree_replaceable = fake_repair

        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual(repair_seen, [str(opti)])
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["originals"]["OptiScaler/"]["kind"], "tar_tree")

    def test_permission_locked_root_file_is_archived_before_exact_file_repair(self):
        self.game.dlss = True
        self.game.dlssg = True
        legacy = self.target / "OptiScaler.ini"
        legacy.write_bytes(b"legacy ini")
        archive_meta = {"name": "fixture.zip", "sha256": "4" * 64, "known_tag": "fixture"}

        real_copy_verified = self.m.copy_verified
        def deny_legacy(src, dst):
            if Path(src) == legacy:
                raise PermissionError("fixture EACCES")
            return real_copy_verified(src, dst)
        self.m.copy_verified = deny_legacy

        def fake_file_tar(src, backup_root, rel):
            archive = backup_root / "file-tars" / (rel + ".tar")
            archive.parent.mkdir(parents=True, exist_ok=True)
            with tarfile.open(archive, "w") as tf:
                tf.add(src, arcname=Path(rel).name)
            return {
                "kind": "tar_file", "existed": True, "backup": str(archive),
                "member": Path(rel).name, "restore_parent": ".",
                "bytes": archive.stat().st_size, "archive_sha256": self.m.sha256_file(archive),
                "preserves_numeric_owner": True,
            }
        self.m._backup_file_tar = fake_file_tar

        repair_seen = []
        real_file_repair = self.m.ensure_file_replaceable
        def fake_file_repair(path, label):
            if Path(path) == legacy:
                baseline = self.m.load_baseline(self.target)
                self.assertIsNotNone(baseline, "file repair happened before baseline.json existed")
                self.assertEqual(baseline["originals"]["OptiScaler.ini"]["kind"], "tar_file")
                repair_seen.append(str(path))
                return True
            return real_file_repair(path, label)
        self.m.ensure_file_replaceable = fake_file_repair

        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual(repair_seen, [str(legacy)])
        baseline = self.m.load_baseline(self.target)
        self.assertEqual(baseline["originals"]["OptiScaler.ini"]["kind"], "tar_file")



    def test_batch_report_history_is_capped_per_action(self):
        import time
        self.m.STATE_ROOT = self.base / "state-report-cap"
        self.m.STATE_ROOT.mkdir(parents=True)
        paths = []
        for i in range(8):
            path = self.m.STATE_ROOT / f"audit-20000101-00000{i}.md"
            path.write_text(str(i), encoding="utf-8")
            paths.append(path)
            time.sleep(0.002)
        # Force a uniquely newer report name while avoiding dependence on wall-clock seconds.
        real_stamp = self.m.now_stamp
        self.m.now_stamp = lambda: "20990101-999999"
        try:
            newest = self.m.write_batch_report("audit", [], self.base)
        finally:
            self.m.now_stamp = real_stamp
        kept = sorted(self.m.STATE_ROOT.glob("audit-*.md"))
        self.assertEqual(len(kept), 5)
        self.assertIn(newest, kept)

    def test_install_history_is_capped_to_ten_compact_rows(self):
        b = self._baseline(history=[{"installed_utc": f"old-{i}"} for i in range(15)])
        self.game.dlss = True
        self.game.dlssg = True
        # Active refresh requires valid current metadata; use a fresh baseline
        # created by a real install, then inject oversized history before refresh.
        self.m.baseline_path(self.target).unlink()
        archive_meta = {"name": "fixture.zip", "sha256": "5" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        active = self.m.load_baseline(self.target)
        active["history"] = [{"installed_utc": f"old-{i}"} for i in range(15)]
        self.m.save_json_atomic(self.m.baseline_path(self.target), active)
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        reloaded = self.m.load_baseline(self.target)
        self.assertEqual(len(reloaded["history"]), 10)
        self.assertEqual(reloaded["history"][-1]["archive_sha256"], "5" * 64)



    def _write_dlss_provider_zip(self, path: Path, extra_entries=None) -> str:
        entries = {
            "dxgi.dll": b"MZ" + b"x" * 1024,
            "OptiScaler.ini": b"[Menu]\nOverlayMenu=true\n",
            "nvngx.dll_dlssnr.dll": b"MZnr-alias",
            "nvngx_dlssnr.dll": b"MZnr",
            "OptiScaler/core.dll": b"MZcore",
            "OptiScaler/dlssg_sm86/dlssg_sm86.dll": b"MZsm86",
            "OptiScaler/dlssg_sm86/dlssg_sm86.ini": b"[x]\n",
            "OptiScaler/streamline/sl.interposer.dll": b"MZsl",
            "OptiScaler/streamline/sl.dlss_g.dll": b"MZslg",
            "Licenses/LICENSE.txt": b"fixture",
        }
        if extra_entries:
            entries.update(extra_entries)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            for name, data in entries.items():
                zf.writestr(name, data)
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def _write_rtxmfg_zip(self, path: Path, *, duplicate=False, traversal=False, symlink=False) -> str:
        payload = b"MZ" + b"R" * (70 * 1024)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_STORED) as zf:
            if traversal:
                zf.writestr("../RTXMFG.dll", payload)
            elif symlink:
                info = zipfile.ZipInfo("RTXMFG.dll")
                info.create_system = 3
                info.external_attr = (0o120777 << 16)
                zf.writestr(info, b"target")
            else:
                zf.writestr("RTXMFG.dll", payload)
                if duplicate:
                    zf.writestr("nested/RTXMFG.dll", payload)
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def test_ada_ini_policy_disables_internal_fg_and_enables_nr(self):
        out = self.m.patch_optiscaler_ini(
            b"[Menu]\nOverlayMenu=true\n[DLSSG]\nAdaMfgUnlock=true\nAmpereMfgUnlock=true\n",
            "ada",
        ).decode("utf-8")
        expected = {
            "OverlayMenu=false", "ShortcutKey=45", "UseHQFont=false", "DisableSplash=true",
            "CheckForUpdate=false", "Dx12Upscaler=dlss", "Enabled=true", "RunBeforeSR=true",
            "DeferredDLSS=false", "ResidualFG=false", "Passes=1", "WorkingScale=1.0",
            "External=true", "FGInput=nofg", "FGOutput=nofg", "FGNvngxReplacement=None",
            "AmpereMfgUnlock=false", "AdaMfgUnlock=false", "AdaBlackwellKernels=auto",
            "InterpolationCount=auto", "OverrideInterpolationCount=auto",
            "OverrideForceDMFG=false", "ForceDMFG=false",
        }
        for line in expected:
            self.assertIn(line, out)
        self.assertIn("[DlssNr]", out)
        self.assertIn("[FrameGen]", out)

    def test_ada_integrated_v3e_runtime_is_pinned_and_retires_186_external_proxy(self):
        runtime, runtime_meta = self.m.load_integrated_ada_runtime()
        self.assertEqual(
            self.m.sha256_bytes(runtime),
            "95580ebc7d2f562d6d99cd798587f757a51cd7bd52e24b0895c42414c3a3c2e8",
        )
        self.assertEqual(runtime_meta["commit"], "deca7b7a8f1953de3cf6fe2731ede440b3ddaadf")
        self.game.dlss = True
        self.game.dlssg = True
        write_minimal_pe(self.exe, ["winmm.dll", "dxgi.dll"])
        archive_meta = {"name": "fixture.zip", "sha256": "7" * 64, "known_tag": "fixture"}

        # Start from the Handoff-186 external-owner shape so the production
        # transition is exercised, not just a pristine 187 install.
        external_bytes = b"MZ-external-rtxmfg"
        external_meta = {
            "version": "fixture",
            "sha256": "8" * 64,
            "dll_sha256": self.m.sha256_bytes(external_bytes),
        }
        prior = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            rtxmfg_payload=external_bytes, rtxmfg_meta=external_meta,
        )
        self.assertEqual(prior["mfg_provider"]["proxy"], "winmm.dll")
        self.assertTrue((self.target / "winmm.dll").is_file())

        record = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime,
            ada_runtime_meta=runtime_meta,
        )
        self.assertEqual(record["mfg_provider"]["ownership"], "integrated")
        self.assertEqual(record["mfg_provider"]["dll_sha256"], runtime_meta["sha256"])
        self.assertIsNone(record["mfg_provider"].get("proxy"))
        self.assertFalse(record["nr_profile"]["enabled"])
        self.assertFalse((self.target / "winmm.dll").exists())
        self.assertEqual((self.target / record["proxy"]).read_bytes(), runtime)
        ini = (self.target / "OptiScaler.ini").read_text(encoding="utf-8")
        for line in (
            "FGInput=dlssg", "FGOutput=dlssg", "FGNvngxReplacement=none",
            "AdaMfgUnlock=true", "AdaBlackwellKernels=true",
            "DisableFlipMetering=true", "DisableReflexSync=true",
        ):
            self.assertIn(line, ini)
        self.assertRegex(ini, r"(?s)\[DlssNr\].*?Enabled=false")
        self.assertNotIn("winmm=n,b", record["launch_options"])

    def test_rc2_integrated_policy_minimizes_spoofing_and_preserves_native_sr_route(self):
        raw = (
            b"[Upscalers]\nDx12Upscaler=xess\n"
            b"[Spoofing]\nDxgi=auto\nStreamlineSpoofing=auto\n"
            b"[Hotfix]\nDisableOverlays=false\n"
        )
        out = self.m.patch_optiscaler_ini(raw, "ada", ada_mfg_mode="integrated").decode("utf-8")
        self.assertRegex(out, r"(?s)\[Upscalers\].*?Dx12Upscaler=xess")
        self.assertRegex(out, r"(?s)\[Spoofing\].*?Dxgi=false")
        self.assertRegex(out, r"(?s)\[Spoofing\].*?StreamlineSpoofing=false")
        self.assertRegex(out, r"(?s)\[Hotfix\].*?DisableOverlays=false")

    def test_rc2_eos_overlay_enables_builtin_overlay_blocker(self):
        eos = self.game.root / "Engine" / "Binaries" / "ThirdParty" / "EOS"
        eos.mkdir(parents=True)
        (eos / "EOSOVH-Win64-Shipping.dll").write_bytes(b"fixture")
        self.game.dlss = True
        self.game.dlssg = True
        runtime, runtime_meta = self.m.load_integrated_ada_runtime()
        archive_meta = {"name": "fixture.zip", "sha256": "c" * 64, "known_tag": "fixture"}
        record = self.m.install_target(
            self.game, self._sm86_payload(), archive_meta, "ada",
            ada_mfg_mode="integrated",
            ada_runtime_payload=runtime, ada_runtime_meta=runtime_meta,
        )
        self.assertTrue(record["compatibility_policy"]["eos_overlay_detected"])
        self.assertTrue(record["compatibility_policy"]["overlay_blocker_enabled"])
        ini = (self.target / "OptiScaler.ini").read_text(encoding="utf-8")
        self.assertRegex(ini, r"(?s)\[Hotfix\].*?DisableOverlays=true")

    def test_rc2_runtime_evidence_uses_execution_marker_not_overlay_presence(self):
        (self.target / "OptiScaler.log").write_text(
            "loader started\n"
            "RTXForge.NativeMfgMenu.v3e: applied native interpolation request "
            "generation=7 sourceViewport=0 outputViewport=0 nativeFrames=3 outputFrames=3\n",
            encoding="utf-8",
        )
        evidence = self.m.inspect_optiscaler_runtime_log(self.target)
        self.assertEqual(evidence["status"], "mfg-applied")
        self.assertTrue(evidence["mfg_applied"])
        self.assertTrue(evidence["native_bridge_seen"])

    def test_sm86_ini_policy_keeps_ampere_route_and_nr(self):
        out = self.m.patch_optiscaler_ini(b"[DLSSG]\nAmpereMfgUnlock=false\n", "sm86").decode("utf-8")
        self.assertIn("AmpereMfgUnlock=true", out)
        self.assertIn("AdaMfgUnlock=false", out)
        self.assertIn("External=true", out)
        self.assertIn("Enabled=false", out)
        self.assertIn("[DlssNr]", out)
        self.assertIn("RunBeforeSR=true", out)
        self.assertIn("WorkingScale=1.0", out)

    def test_dlss_provider_zip_structure_validation_and_case_collision_refusal(self):
        good = self.base / "renamed-provider.zip"
        digest = self._write_dlss_provider_zip(good)
        self.m.KNOWN_ARCHIVES = {"official.zip": {"sha256": digest, "tag": "fixture"}}
        meta = self.m.validate_archive(good)
        self.assertEqual(meta["sha256"], digest)
        self.assertEqual(meta["known_tag"], "fixture")
        payload, _ = self.m.load_archive_payload(good)
        self.assertIn("OptiScaler/streamline/sl.interposer.dll", payload)

        collision = self.base / "collision.zip"
        digest2 = self._write_dlss_provider_zip(collision, {"OPTISCALER/core.dll": b"duplicate-case"})
        self.m.KNOWN_ARCHIVES = {"official.zip": {"sha256": digest2, "tag": "fixture"}}
        with self.assertRaises(self.m.Stop):
            self.m.load_archive_payload(collision)

    def test_rtxmfg_zip_validation_rejects_duplicate_traversal_and_symlink(self):
        for label, kwargs in (
            ("duplicate", {"duplicate": True}),
            ("traversal", {"traversal": True}),
            ("symlink", {"symlink": True}),
        ):
            path = self.base / f"{label}.zip"
            digest = self._write_rtxmfg_zip(path, **kwargs)
            with self.subTest(label=label):
                with self.assertRaises(self.m.Stop):
                    self.m._safe_zip_payload_single_file(path, "RTXMFG.dll", digest)

    def test_rtxmfg_download_cache_validates_hash_and_cleans_part_on_failure(self):
        source = self.base / "source.zip"
        digest = self._write_rtxmfg_zip(source)
        blob = source.read_bytes()
        self.m.DEFAULT_DOWNLOAD_DIR = self.base / "Downloads" / "Compressed"
        self.m.RTXMFG_CACHE_DIR = self.base / "cache"
        self.m.RTXMFG_PROVIDER = {
            "version": "fixture", "archive": "RTXMFG-fixture.zip",
            "sha256": digest, "url": "https://example.invalid/RTXMFG-fixture.zip",
        }
        self.m.urllib.request.urlopen = lambda *a, **k: io.BytesIO(blob)
        cached = self.m.ensure_rtxmfg_archive(allow_download=True)
        self.assertTrue(cached.is_file())
        self.assertEqual(self.m.sha256_file(cached), digest)
        self.assertFalse(list(self.m.RTXMFG_CACHE_DIR.glob("*.part-*")))
        self.assertFalse(list(self.m.RTXMFG_CACHE_DIR.glob(".*.part-*")))

        cached.unlink()
        self.m.RTXMFG_PROVIDER["sha256"] = "0" * 64
        with self.assertRaises(self.m.Stop):
            self.m.ensure_rtxmfg_archive(allow_download=True)
        self.assertFalse(list(self.m.RTXMFG_CACHE_DIR.glob("*.part-*")))
        self.assertFalse(list(self.m.RTXMFG_CACHE_DIR.glob(".*.part-*")))

    def test_newly_quarantined_orphan_is_never_pruned_by_older_mtime_history(self):
        state = self.m.state_dir_for(self.target)
        backup = state / "baseline-backup"
        backup.mkdir(parents=True)
        (backup / "fresh-recovery.bin").write_bytes(b"fresh")
        # Make the current orphan source look ancient by mtime.
        os.utime(backup, ns=(1, 1))
        old = state / "baseline-backup-orphan-old"
        old.mkdir()
        (old / "old.bin").write_bytes(b"old")
        os.utime(old, ns=(9_999_999_999, 9_999_999_999))

        archived = self.m.quarantine_orphan_baseline_backup(self.target)
        self.assertIsNotNone(archived)
        self.assertTrue((archived / "fresh-recovery.bin").is_file())
        self.assertFalse(old.exists())

    def test_stale_orphan_baseline_is_quarantined_and_retention_is_capped(self):
        state = self.m.state_dir_for(self.target)
        backup = state / "baseline-backup"
        backup.mkdir(parents=True)
        (backup / "old.bin").write_bytes(b"old")
        archived = self.m.quarantine_orphan_baseline_backup(self.target)
        self.assertIsNotNone(archived)
        self.assertFalse(backup.exists())
        self.assertTrue(archived.is_dir())
        # A second orphan generation should prune the older one to keep only one.
        backup.mkdir(parents=True)
        (backup / "new.bin").write_bytes(b"new")
        archived2 = self.m.quarantine_orphan_baseline_backup(self.target)
        orphans = list(state.glob("baseline-backup-orphan-*"))
        self.assertEqual(len(orphans), 1)
        self.assertEqual(orphans[0], archived2)


    def test_launchoptions_ownership_ignores_managed_lookalikes_after_command(self):
        original = 'MANGOHUD=1 %command% --foo'
        required = (
            'WINEDLLOVERRIDES="dxgi=n,b" '
            'PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        )
        applied = self.m.merge_rtxengine_launch_options(original, required)
        self.assertIn('WINEDLLOVERRIDES="dxgi=n,b"', applied)
        current = applied + ' PROTON_ENABLE_NVAPI=0 WINEDLLOVERRIDES=literal-game-arg'

        restored = self.m.reconcile_rtxengine_launch_options(current, original, applied)
        self.assertEqual(
            restored,
            'MANGOHUD=1 %command% --foo PROTON_ENABLE_NVAPI=0 WINEDLLOVERRIDES=literal-game-arg',
        )

    def test_launchoptions_merge_does_not_import_post_command_wine_override_argument(self):
        existing = '%command% WINEDLLOVERRIDES=literal-game-arg --dx12'
        required = (
            'WINEDLLOVERRIDES="version=n,b" '
            'PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        )
        merged = self.m.merge_rtxengine_launch_options(existing, required)
        self.assertTrue(merged.startswith('WINEDLLOVERRIDES="version=n,b" '))
        self.assertIn('%command% WINEDLLOVERRIDES=literal-game-arg --dx12', merged)

    def test_launch_option_merge_preserves_mangohud_gamescope_args_and_existing_overrides(self):
        existing = 'MANGOHUD=1 WINEDLLOVERRIDES="dinput8=n,b" gamescope -f %command% -dx12'
        required = 'WINEDLLOVERRIDES="dxgi=n,b;version=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        merged = self.m.merge_rtxengine_launch_options(existing, required)
        self.assertIn("MANGOHUD=1", merged)
        self.assertIn("gamescope -f %command% -dx12", merged)
        self.assertIn("dinput8=n,b", merged)
        self.assertIn("dxgi=n,b", merged)
        self.assertIn("version=n,b", merged)
        self.assertEqual(merged.count("%command%"), 1)
        self.assertEqual(merged.count("PROTON_ENABLE_NVAPI=1"), 1)
        self.assertEqual(merged.count("PROTON_NVIDIA_NVCUDA=1"), 0)

    def test_launchoptions_build_contract_does_not_force_legacy_nvcuda(self):
        launch = self.m.build_launch_options("dxgi.dll", {"detected": False})
        self.assertIn('WINEDLLOVERRIDES="dxgi=n,b"', launch)
        self.assertIn("PROTON_ENABLE_NVAPI=1", launch)
        self.assertNotIn("PROTON_NVIDIA_NVCUDA", launch)

    def test_launchoptions_refresh_removes_legacy_nvcuda_without_touching_user_flags(self):
        existing = (
            'PROTON_NVIDIA_NVCUDA=1 WINEDLLOVERRIDES="dwmapi=n,b" '
            'MANGOHUD=1 gamescope -f %command% -dx12'
        )
        required = 'WINEDLLOVERRIDES="wininet=n,b" PROTON_ENABLE_NVAPI=1 %command%'
        merged = self.m.merge_rtxengine_launch_options(existing, required)
        self.assertNotIn("PROTON_NVIDIA_NVCUDA", merged)
        self.assertIn('WINEDLLOVERRIDES="dwmapi=n,b;wininet=n,b"', merged)
        self.assertIn("MANGOHUD=1 gamescope -f %command% -dx12", merged)

    def test_launchoptions_preserves_halo_dwmapi_override(self):
        existing = 'WINEDLLOVERRIDES="dwmapi=n,b" %command%'
        required = 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 %command%'
        merged = self.m.merge_rtxengine_launch_options(existing, required)
        self.assertIn('WINEDLLOVERRIDES="dwmapi=n,b;dxgi=n,b"', merged)
        self.assertEqual(merged.count("%command%"), 1)

    def test_launchoptions_refuses_managed_assignment_after_wrapper_command(self):
        existing = 'gamescope -f WINEDLLOVERRIDES="dwmapi=n,b" %command%'
        required = 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 %command%'
        with self.assertRaises(self.m.Stop) as cm:
            self.m.merge_rtxengine_launch_options(existing, required)
        self.assertIn("refusing unsafe automatic rewrite", str(cm.exception))

    def test_launchoptions_refuses_env_wrapper_managed_assignment_instead_of_reordering_it(self):
        existing = 'env PROTON_ENABLE_NVAPI=0 %command% --foo'
        required = 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 %command%'
        with self.assertRaises(self.m.Stop) as cm:
            self.m.merge_rtxengine_launch_options(existing, required)
        self.assertIn("PROTON_ENABLE_NVAPI", str(cm.exception))

    def test_batch_reports_same_timestamp_are_unique_and_atomic(self):
        with patch.object(self.m, "now_stamp", return_value="20260911-190000"):
            first = self.m.write_batch_report("audit", [], self.drive)
            second = self.m.write_batch_report("audit", [], self.drive)
        self.assertNotEqual(first, second)
        self.assertTrue(first.is_file())
        self.assertTrue(second.is_file())
        self.assertEqual(first.name, "audit-20260911-190000.md")
        self.assertEqual(second.name, "audit-20260911-190000-1.md")
        self.assertTrue(first.read_text(encoding="utf-8").endswith("\n"))
        self.assertTrue(second.read_text(encoding="utf-8").endswith("\n"))

    def test_audit_refuses_destructive_pending_recovery_state(self):
        current = {
            "installed_hashes": {},
            "proxy": "dxgi.dll",
            "mfg_provider": None,
            "nr_profile": {},
            "launch_options": "%command%",
        }
        baseline = self._baseline(current=current)
        baseline["status"] = "destructive-pending"
        baseline["destructive_pending"] = {"mode": "deep-clean", "previous_status": "active"}
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)
        with self.assertRaises(self.m.Stop) as cm:
            self.m.audit_target(self.game)
        self.assertIn("not active", str(cm.exception))

    def test_audit_detects_changed_and_missing_and_report_preserves_provenance(self):
        good = self.target / "dxgi.dll"
        changed = self.target / "OptiScaler.ini"
        good.write_bytes(b"good")
        changed.write_bytes(b"before")
        b = self._baseline(current={
            "installed_hashes": {
                "dxgi.dll": self.m.sha256_bytes(b"good"),
                "OptiScaler.ini": self.m.sha256_bytes(b"before"),
                "OptiScaler/missing.dll": self.m.sha256_bytes(b"missing"),
            },
            "proxy": "dxgi.dll",
            "mfg_provider": {
                "name": "Universal RTXMFG", "version": "fixture", "ownership": "external",
                "dll_sha256": "a" * 64, "menu_key": "Backspace",
            },
            "nr_profile": {"enabled": True, "run_before_sr": True, "passes": 1, "working_scale": 1.0, "menu_key": "Insert"},
            "launch_options": 'WINEDLLOVERRIDES="dxgi=n,b" %command%',
        })
        changed.write_bytes(b"after")
        row = self.m.audit_target(self.game)
        self.assertEqual(row["missing"], ["OptiScaler/missing.dll"])
        self.assertEqual(row["changed"], ["OptiScaler.ini"])
        row["status"] = "drift"
        report = self.m.write_batch_report(
            "audit", [row], self.drive,
            {"name": "provider.zip", "sha256": "b" * 64},
        )
        text = report.read_text(encoding="utf-8")
        self.assertIn("Status: `drift`", text)
        self.assertIn("MFG provider: `Universal RTXMFG fixture` (`external` owner)", text)
        self.assertIn("MFG DLL SHA256", text)
        self.assertIn("NR profile", text)
        self.assertIn("OptiScaler/NR menu key: `Insert`", text)
        self.assertIn("Missing: 1", text)
        self.assertIn("Changed: 1", text)
        self.assertIn("Archive SHA256", text)

    def test_official_provider_pin_constants_are_unchanged(self):
        self.assertEqual(
            self.m.KNOWN_ARCHIVES["dlss-unlocked-standalone-DLSSNR-v0.7.6.zip"]["sha256"],
            "ca824acb693e39975b152c7a6aa21af64799dc1d05ec0462451491ccda8e6ec2",
        )
        self.assertEqual(self.m.RTXMFG_PROVIDER["version"], "v1.3.2")
        self.assertEqual(
            self.m.RTXMFG_PROVIDER["sha256"],
            "7baec084500bcc806be488c17b4822fdef0ecc802fd7d23c5be8184fbe660811",
        )

    def test_streaming_binary_marker_scan_handles_chunk_boundaries_and_case(self):
        path = self.base / "proxy.dll"
        path.write_bytes(b"A" * 15 + b"OpTiScAlEr" + b"Z" * 20)
        self.assertTrue(
            self.m.file_contains_any(
                path, (b"reshade", b"optiscaler"), max_bytes=1024, chunk_size=8
            )
        )
        self.assertFalse(
            self.m.file_contains_any(
                path, (b"not-present", b"rtxmfg"), max_bytes=1024, chunk_size=8
            )
        )

    def test_streaming_binary_marker_scan_respects_size_cap_and_symlink_boundary(self):
        path = self.base / "large.dll"
        path.write_bytes(b"optiscaler" + b"x" * 64)
        self.assertFalse(self.m.file_contains_any(path, (b"optiscaler",), max_bytes=4, chunk_size=2))
        link = self.base / "link.dll"
        link.symlink_to(path)
        self.assertFalse(self.m.file_contains_any(link, (b"optiscaler",), max_bytes=1024, chunk_size=8))

    def test_cli_help_smoke(self):
        cp = subprocess.run(
            [sys.executable, str(SCRIPT), "--help"],
            text=True, capture_output=True, check=False,
        )
        self.assertEqual(cp.returncode, 0, cp.stderr)
        self.assertIn("rtxEngine Terminal Edition v13", cp.stdout)
        self.assertIn("--deep-clean-all", cp.stdout)
        self.assertIn("--verify-queue-auto", cp.stdout)


    def test_restore_preserves_runtime_drift_inside_optiscaler_tree(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "6" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")

        runtime_log = self.target / "OptiScaler" / "runtime-created.log"
        runtime_log.write_text("runtime diagnostics", encoding="utf-8")
        managed = self.target / "OptiScaler" / "core.dll"
        managed.write_bytes(b"user-edited-core")

        row = self.m.restore_target(self.game)
        recovery = Path(row["recovery"])
        self.assertEqual(
            (recovery / "OptiScaler" / "runtime-created.log").read_text(encoding="utf-8"),
            "runtime diagnostics",
        )
        self.assertEqual(
            (recovery / "OptiScaler" / "core.dll").read_bytes(),
            b"user-edited-core",
        )

    def test_restore_refuses_live_optiscaler_symlink_before_deleting_tree(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "7" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        outside = self.base / "outside-runtime.txt"
        outside.write_text("keep", encoding="utf-8")
        link = self.target / "OptiScaler" / "runtime-link"
        link.symlink_to(outside)

        with self.assertRaises(self.m.Stop):
            self.m.restore_target(self.game)
        self.assertTrue((self.target / "OptiScaler").is_dir())
        self.assertEqual(outside.read_text(encoding="utf-8"), "keep")
        self.assertTrue(self.m.baseline_path(self.target).is_file())


    def test_mixed_steam_and_nonsteam_launchoptions_restore_in_one_batch(self):
        steam_root = self.base / "Steam"
        config_dir = steam_root / "userdata" / "42" / "config"
        config_dir.mkdir(parents=True, exist_ok=True)
        localconfig = config_dir / "localconfig.vdf"
        current_steam = 'WINEDLLOVERRIDES="dxgi=n,b" MANGOHUD=1 %command%'
        original_steam = 'MANGOHUD=1 %command%'
        localconfig.write_text(
            '"UserLocalConfigStore"\n{\n\t"Software"\n\t{\n\t\t"Valve"\n\t\t{\n\t\t\t"Steam"\n\t\t\t{\n\t\t\t\t"apps"\n\t\t\t\t{\n\t\t\t\t\t"123"\n\t\t\t\t\t{\n'
            f'\t\t\t\t\t\t"LaunchOptions"\t\t"{current_steam.replace(chr(34), chr(92)+chr(34))}"\n'
            '\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n}\n',
            encoding="utf-8",
        )
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True

        self.game.installed = True
        self.game.reason = "INSTALLED"
        steam_b = self._baseline()
        steam_b["steam_launch"] = {
            "kind": "steam", "config_path": str(localconfig), "steam_userid": "42",
            "appid": "123", "original": original_steam, "applied": current_steam,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), steam_b)

        non_root = self.drive / "Non-Steam Games" / "Other"
        non_target = non_root / "Binaries" / "Win64"
        non_target.mkdir(parents=True)
        non_exe = non_target / "other.exe"
        non_exe.write_bytes(b"MZother")
        non = self.m.Game("B", "Other", non_root, "Non-Steam", None, None, non_exe, non_target, installed=True, reason="INSTALLED")
        original_non = 'gamescope -f %command% -dx12'
        applied_non = 'WINEDLLOVERRIDES="version=n,b" gamescope -f %command% -dx12'
        shortcuts = config_dir / "shortcuts.vdf"
        shortcuts.write_bytes(make_shortcuts_fixture(non, applied_non))
        non_state = {
            "schema": 13, "status": "active", "created_utc": self.m.now_iso(),
            "name": non.name, "source": non.source, "appid": None,
            "exe": str(non_exe), "target_dir": str(non_target),
            "originals": {}, "managed_paths": [], "history": [], "current": {"installed_hashes": {}},
            "steam_launch": {
                "kind": "shortcut", "config_path": str(shortcuts), "steam_userid": "42",
                "shortcut_appid": 0x1234567, "shortcut_appname": non.name,
                "shortcut_exe": str(non_exe), "original": original_non, "applied": applied_non,
            },
        }
        self.m.state_dir_for(non_target).mkdir(parents=True, exist_ok=True)
        self.m.save_json_atomic(self.m.baseline_path(non_target), non_state)

        rows = self.m.restore_launch_options_batch([self.game, non], assume_yes=True)
        self.assertEqual({row["kind"] for row in rows}, {"Steam", "Non-Steam"})
        self.assertEqual(self.m.read_localconfig_launch_options(localconfig, "123"), original_steam)
        obj = self.m.match_shortcut_span(non, self.m.parse_shortcuts_spans(shortcuts.read_bytes()))
        self.assertEqual(self.m._shortcut_string(obj, "LaunchOptions"), original_non)

    def test_launchoptions_restore_refuses_owned_external_drift_before_any_write(self):
        config = self._steam_localconfig(None)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        original = "%command%"
        required = 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        applied = self.m.merge_rtxengine_launch_options(original, required)
        current = applied.replace("PROTON_ENABLE_NVAPI=1", "PROTON_ENABLE_NVAPI=0")
        self.m.update_localconfig_launch_options(config, {"123": current})
        baseline = self._baseline()
        baseline["steam_launch"] = {
            "kind": "steam", "config_path": str(config), "steam_userid": "42",
            "appid": "123", "original": original, "applied": applied, "required": required,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        before = config.read_bytes()
        with self.assertRaises(self.m.Stop) as cm:
            self.m.restore_launch_options_batch([self.game], assume_yes=True)
        self.assertIn("rtxEngine-owned assignment PROTON_ENABLE_NVAPI", str(cm.exception))
        self.assertEqual(config.read_bytes(), before)
        self.assertFalse((self.m.STATE_ROOT / "steam-transactions").exists())
        self.assertFalse((self.m.STATE_ROOT / "steam-config-backups").exists())

    def test_launchoptions_restore_preserves_unrelated_post_install_edits(self):
        config = self._steam_localconfig(None)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        original = 'MANGOHUD=1 gamescope -f %command% -dx12'
        required = 'WINEDLLOVERRIDES="dxgi=n,b;version=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        applied = self.m.merge_rtxengine_launch_options(original, required)
        current = applied + ' USERFLAG=1 -newarg'
        self.m.update_localconfig_launch_options(config, {"123": current})
        baseline = self._baseline()
        baseline["steam_launch"] = {
            "kind": "steam", "config_path": str(config), "steam_userid": "42",
            "appid": "123", "original": original, "applied": applied, "required": required,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        rows = self.m.restore_launch_options_batch([self.game], assume_yes=True)
        self.assertEqual(rows[0]["status"], "restored")
        restored = self.m.read_localconfig_launch_options(config, "123")
        self.assertEqual(restored, original + ' USERFLAG=1 -newarg')

    def test_launchoptions_restore_preserves_unrelated_wine_override_and_restores_preexisting_proxy_value(self):
        config = self._steam_localconfig(None)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        original = 'WINEDLLOVERRIDES="dxgi=b;dinput8=n,b" MANGOHUD=1 %command%'
        required = 'WINEDLLOVERRIDES="dxgi=n,b;version=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        applied = self.m.merge_rtxengine_launch_options(original, required)
        # User adds a Wine override rtxEngine never owned after installation.
        current = applied.replace('version=n,b"', 'version=n,b;winhttp=n,b"') + ' EXTRA=1'
        self.m.update_localconfig_launch_options(config, {"123": current})
        baseline = self._baseline()
        baseline["steam_launch"] = {
            "kind": "steam", "config_path": str(config), "steam_userid": "42",
            "appid": "123", "original": original, "applied": applied, "required": required,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        self.m.restore_launch_options_batch([self.game], assume_yes=True)
        restored = self.m.read_localconfig_launch_options(config, "123")
        self.assertIn('WINEDLLOVERRIDES="dxgi=b;dinput8=n,b;winhttp=n,b"', restored)
        self.assertNotIn('version=n,b', restored)
        self.assertIn('MANGOHUD=1 %command% EXTRA=1', restored)

    def test_launchoptions_restore_keeps_new_user_options_when_original_key_was_absent(self):
        config = self._steam_localconfig(None)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        required = 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        applied = self.m.merge_rtxengine_launch_options(None, required)
        current = applied.replace('%command%', 'MANGOHUD=1 %command% -dx12')
        self.m.update_localconfig_launch_options(config, {"123": current})
        baseline = self._baseline()
        baseline["steam_launch"] = {
            "kind": "steam", "config_path": str(config), "steam_userid": "42",
            "appid": "123", "original": None, "applied": applied, "required": required,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), baseline)

        self.m.restore_launch_options_batch([self.game], assume_yes=True)
        self.assertEqual(
            self.m.read_localconfig_launch_options(config, "123"),
            'MANGOHUD=1 %command% -dx12',
        )

    def test_owned_delta_restore_refuses_multiple_winedlloverrides_assignments(self):
        original = '%command%'
        required = 'WINEDLLOVERRIDES="dxgi=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        applied = self.m.merge_rtxengine_launch_options(original, required)
        # A second assignment after %command% is a game argument, not an
        # environment-prefix assignment. It must survive owned-delta restore.
        current = applied + ' WINEDLLOVERRIDES="winhttp=n,b"'
        restored = self.m.reconcile_rtxengine_launch_options(current, original, applied)
        self.assertEqual(restored, '%command% WINEDLLOVERRIDES="winhttp=n,b"')

        # Two actual pre-command assignments remain ambiguous and must refuse.
        current = 'WINEDLLOVERRIDES="dxgi=n,b" WINEDLLOVERRIDES="winhttp=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        with self.assertRaises(self.m.Stop) as cm:
            self.m.reconcile_rtxengine_launch_options(current, original, applied)
        self.assertIn("multiple WINEDLLOVERRIDES", str(cm.exception))

    def test_nonsteam_launchoptions_restore_preserves_unrelated_post_install_edits(self):
        steam_root = self.base / "Steam"
        config_dir = steam_root / "userdata" / "42" / "config"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True

        non_root = self.drive / "Non-Steam Games" / "Delta"
        non_target = non_root / "Binaries" / "Win64"
        non_target.mkdir(parents=True)
        non_exe = non_target / "delta.exe"
        non_exe.write_bytes(b"MZdelta")
        non = self.m.Game("B", "Delta", non_root, "Non-Steam", None, None, non_exe, non_target, installed=True, reason="INSTALLED")
        original = 'gamescope -f %command% -dx12'
        required = 'WINEDLLOVERRIDES="version=n,b" PROTON_ENABLE_NVAPI=1 PROTON_NVIDIA_NVCUDA=1 %command%'
        applied = self.m.merge_rtxengine_launch_options(original, required)
        current = applied + ' USERFLAG=1'
        shortcuts = config_dir / "shortcuts.vdf"
        shortcuts.write_bytes(make_shortcuts_fixture(non, current))
        state = {
            "schema": 13, "status": "active", "created_utc": self.m.now_iso(),
            "name": non.name, "source": non.source, "appid": None,
            "exe": str(non_exe), "target_dir": str(non_target),
            "originals": {}, "managed_paths": [], "history": [], "current": {"installed_hashes": {}},
            "steam_launch": {
                "kind": "shortcut", "config_path": str(shortcuts), "steam_userid": "42",
                "shortcut_appid": 0x1234567, "shortcut_appname": non.name,
                "shortcut_exe": str(non_exe), "original": original, "applied": applied, "required": required,
            },
        }
        self.m.state_dir_for(non_target).mkdir(parents=True, exist_ok=True)
        self.m.save_json_atomic(self.m.baseline_path(non_target), state)

        self.m.restore_launch_options_batch([non], assume_yes=True)
        obj = self.m.match_shortcut_span(non, self.m.parse_shortcuts_spans(shortcuts.read_bytes()))
        self.assertEqual(self.m._shortcut_string(obj, "LaunchOptions"), original + ' USERFLAG=1')

    def test_multiconfig_launchoptions_restore_rolls_back_earlier_write_on_late_failure(self):
        steam_root = self.base / "Steam"
        config_dir = steam_root / "userdata" / "42" / "config"
        config_dir.mkdir(parents=True, exist_ok=True)
        localconfig = config_dir / "localconfig.vdf"
        current_steam = 'WINEDLLOVERRIDES="dxgi=n,b" MANGOHUD=1 %command%'
        original_steam = 'MANGOHUD=1 %command%'
        localconfig.write_text(
            '"UserLocalConfigStore"\n{\n\t"Software"\n\t{\n\t\t"Valve"\n\t\t{\n\t\t\t"Steam"\n\t\t\t{\n\t\t\t\t"apps"\n\t\t\t\t{\n\t\t\t\t\t"123"\n\t\t\t\t\t{\n'
            f'\t\t\t\t\t\t"LaunchOptions"\t\t"{current_steam.replace(chr(34), chr(92)+chr(34))}"\n'
            '\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n}\n',
            encoding="utf-8",
        )
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True
        steam_b = self._baseline()
        steam_b["steam_launch"] = {
            "kind": "steam", "config_path": str(localconfig), "steam_userid": "42",
            "appid": "123", "original": original_steam, "applied": current_steam,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), steam_b)

        non_root = self.drive / "Non-Steam Games" / "OtherRollback"
        non_target = non_root / "Binaries" / "Win64"
        non_target.mkdir(parents=True)
        non_exe = non_target / "other.exe"
        non_exe.write_bytes(b"MZother")
        non = self.m.Game("B", "OtherRollback", non_root, "Non-Steam", None, None, non_exe, non_target, installed=True, reason="INSTALLED")
        original_non = 'gamescope -f %command% -dx12'
        applied_non = 'WINEDLLOVERRIDES="version=n,b" gamescope -f %command% -dx12'
        shortcuts = config_dir / "shortcuts.vdf"
        shortcuts.write_bytes(make_shortcuts_fixture(non, applied_non))
        non_state = {
            "schema": 13, "status": "active", "created_utc": self.m.now_iso(),
            "name": non.name, "source": non.source, "appid": None,
            "exe": str(non_exe), "target_dir": str(non_target),
            "originals": {}, "managed_paths": [], "history": [], "current": {"installed_hashes": {}},
            "steam_launch": {
                "kind": "shortcut", "config_path": str(shortcuts), "steam_userid": "42",
                "shortcut_appid": 0x1234567, "shortcut_appname": non.name,
                "shortcut_exe": str(non_exe), "original": original_non, "applied": applied_non,
            },
        }
        self.m.state_dir_for(non_target).mkdir(parents=True, exist_ok=True)
        self.m.save_json_atomic(self.m.baseline_path(non_target), non_state)

        original_restore = self.m.restore_shortcut_launch_option
        calls = {"count": 0}
        def fail_first_apply_then_allow_rollback(path, locator, value):
            calls["count"] += 1
            if calls["count"] == 1:
                raise self.m.Stop("simulated late shortcut restore failure")
            return original_restore(path, locator, value)
        self.m.restore_shortcut_launch_option = fail_first_apply_then_allow_rollback

        with self.assertRaises(self.m.Stop) as cm:
            self.m.restore_launch_options_batch([self.game, non], assume_yes=True)
        self.assertIn("rolled back safely", str(cm.exception))
        self.assertEqual(self.m.read_localconfig_launch_options(localconfig, "123"), current_steam)
        obj = self.m.match_shortcut_span(non, self.m.parse_shortcuts_spans(shortcuts.read_bytes()))
        self.assertEqual(self.m._shortcut_string(obj, "LaunchOptions"), applied_non)
        self.assertEqual(list((self.m.STATE_ROOT / "steam-transactions").glob("*.json")) if (self.m.STATE_ROOT / "steam-transactions").exists() else [], [])




    def test_postcommit_cleanup_failure_never_rolls_back_remaining_config(self):
        steam_root = self.base / "Steam"
        config_dir = steam_root / "userdata" / "42" / "config"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.m.STEAM_ROOT_CANDIDATES = (steam_root,)
        self.m.ensure_steam_stopped_for_write = lambda assume_yes=False: True

        # Steam game config + baseline.
        localconfig = config_dir / "localconfig.vdf"
        current_steam = 'WINEDLLOVERRIDES="dxgi=n,b" MANGOHUD=1 %command%'
        original_steam = 'MANGOHUD=1 %command%'
        localconfig.write_text(
            '"UserLocalConfigStore"\n{\n\t"Software"\n\t{\n\t\t"Valve"\n\t\t{\n\t\t\t"Steam"\n\t\t\t{\n\t\t\t\t"apps"\n\t\t\t\t{\n\t\t\t\t\t"123"\n\t\t\t\t\t{\n'
            f'\t\t\t\t\t\t"LaunchOptions"\t\t"{current_steam.replace(chr(34), chr(92)+chr(34))}"\n'
            '\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n}\n',
            encoding="utf-8",
        )
        steam_b = self._baseline()
        steam_b["steam_launch"] = {
            "kind": "steam", "config_path": str(localconfig), "steam_userid": "42",
            "appid": "123", "original": original_steam, "applied": current_steam,
        }
        self.m.save_json_atomic(self.m.baseline_path(self.target), steam_b)

        # Non-Steam shortcut config + baseline gives the restore two journals.
        non_root = self.drive / "Non-Steam Games" / "CommittedCleanup"
        non_target = non_root / "Binaries" / "Win64"
        non_target.mkdir(parents=True)
        non_exe = non_target / "other.exe"
        non_exe.write_bytes(b"MZother")
        non = self.m.Game("B", "CommittedCleanup", non_root, "Non-Steam", None, None, non_exe, non_target, installed=True, reason="INSTALLED")
        original_non = 'gamescope -f %command% -dx12'
        applied_non = 'WINEDLLOVERRIDES="version=n,b" gamescope -f %command% -dx12'
        shortcuts = config_dir / "shortcuts.vdf"
        shortcuts.write_bytes(make_shortcuts_fixture(non, applied_non))
        non_state = {
            "schema": 13, "status": "active", "created_utc": self.m.now_iso(),
            "name": non.name, "source": non.source, "appid": None,
            "exe": str(non_exe), "target_dir": str(non_target),
            "originals": {}, "managed_paths": [], "history": [], "current": {"installed_hashes": {}},
            "steam_launch": {
                "kind": "shortcut", "config_path": str(shortcuts), "steam_userid": "42",
                "shortcut_appid": 0x1234567, "shortcut_appname": non.name,
                "shortcut_exe": str(non_exe), "original": original_non, "applied": applied_non,
            },
        }
        self.m.state_dir_for(non_target).mkdir(parents=True, exist_ok=True)
        self.m.save_json_atomic(self.m.baseline_path(non_target), non_state)

        original_complete = self.m.complete_steam_transaction
        calls = {"n": 0}
        def complete_one_then_fail(path, data):
            calls["n"] += 1
            original_complete(path, data)
            if calls["n"] == 1:
                raise OSError("simulated cleanup failure after first journal removal")
        self.m.complete_steam_transaction = complete_one_then_fail
        try:
            with self.assertRaises(self.m.Stop) as cm:
                self.m.restore_launch_options_batch([self.game, non], assume_yes=True)
        finally:
            self.m.complete_steam_transaction = original_complete

        self.assertIn("committed successfully, but transaction cleanup was incomplete", str(cm.exception))
        # Both config writes were committed before the marker; neither may be
        # partially rolled back because cleanup failed afterward.
        self.assertEqual(self.m.read_localconfig_launch_options(localconfig, "123"), original_steam)
        obj = self.m.match_shortcut_span(non, self.m.parse_shortcuts_spans(shortcuts.read_bytes()))
        self.assertEqual(self.m._shortcut_string(obj, "LaunchOptions"), original_non)
        tx_root = self.m._steam_transaction_root()
        markers = list(tx_root.glob("batch-*.commit"))
        self.assertEqual(len(markers), 1)
        self.assertTrue(list(tx_root.glob("*.json")), "remaining journal must survive for cleanup recovery")

        rows = self.m.recover_pending_steam_transactions(assume_yes=True)
        self.assertTrue(any(r["status"] == "commit-cleanup-completed" for r in rows))
        self.assertEqual(self.m.read_localconfig_launch_options(localconfig, "123"), original_steam)
        obj = self.m.match_shortcut_span(non, self.m.parse_shortcuts_spans(shortcuts.read_bytes()))
        self.assertEqual(self.m._shortcut_string(obj, "LaunchOptions"), original_non)
        self.assertFalse(list(tx_root.glob("*.json")))
        self.assertFalse(list(tx_root.glob("batch-*.commit")))

    def test_failed_restore_is_durably_marked_recovery_before_live_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "8" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        proxy = self.target / "dxgi.dll"
        real_unlink = self.m.durable_unlink
        saw_pending = {"value": False}

        def fail_first_live_unlink(path, *args, **kwargs):
            if Path(path) == proxy:
                state = self.m.load_baseline(self.target)
                saw_pending["value"] = state.get("status") == "restore-pending"
                raise OSError("simulated crash at first live unlink")
            return real_unlink(path, *args, **kwargs)

        self.m.durable_unlink = fail_first_live_unlink
        try:
            with self.assertRaises(OSError):
                self.m.restore_target(self.game)
        finally:
            self.m.durable_unlink = real_unlink
        self.assertTrue(saw_pending["value"])
        state = self.m.load_baseline(self.target)
        self.assertEqual(state["status"], "restore-pending")
        self.assertEqual(state["restore_pending"]["previous_status"], "active")
        states = self.m.load_installed_states_under_drive(self.drive)
        recorded = next(g for g in states if g.target_dir == self.target)
        self.assertEqual(recorded.reason, "RECOVERY")
        with self.assertRaises(self.m.Stop) as cm:
            self.m.audit_target(recorded)
        self.assertIn("not active", str(cm.exception))
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertIn("restore/uninstall is still pending", str(cm.exception))

    def test_restore_pending_retry_remains_idempotent_and_completes(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "7" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        proxy = self.target / "dxgi.dll"
        real_unlink = self.m.durable_unlink
        failed = {"value": False}
        def fail_once(path, *args, **kwargs):
            if Path(path) == proxy and not failed["value"]:
                failed["value"] = True
                raise OSError("simulated first restore interruption")
            return real_unlink(path, *args, **kwargs)
        self.m.durable_unlink = fail_once
        try:
            with self.assertRaises(OSError):
                self.m.restore_target(self.game)
        finally:
            self.m.durable_unlink = real_unlink
        result = self.m.restore_target(self.game)
        self.assertFalse(self.m.baseline_path(self.target).exists())
        receipt = Path(result["archived_state"])
        self.assertEqual(json.loads(receipt.read_text(encoding="utf-8"))["status"], "restored")

    def test_restore_retry_never_overwrites_preserved_drift_with_restored_original(self):
        original = self.target / "OptiScaler.ini"
        original.write_bytes(b"game-original")
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "a" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        original.write_bytes(b"user-drift-first")

        real_replace = self.m.durable_replace
        failed = {"done": False}
        def fail_before_baseline_archive(src, dst):
            if (
                not failed["done"]
                and Path(src) == self.m.baseline_path(self.target)
                and Path(dst).name.startswith("baseline-restored-")
            ):
                failed["done"] = True
                raise OSError("simulated crash after original bytes were restored")
            return real_replace(src, dst)
        self.m.durable_replace = fail_before_baseline_archive
        try:
            with self.assertRaises(OSError):
                self.m.restore_target(self.game)
        finally:
            self.m.durable_replace = real_replace

        baseline = self.m.load_baseline(self.target)
        self.assertIsNotNone(baseline)
        recovery = Path(baseline["restore_recovery_dir"])
        preserved = recovery / "OptiScaler.ini"
        self.assertEqual(preserved.read_bytes(), b"user-drift-first")
        self.assertEqual(original.read_bytes(), b"game-original")

        self.m.restore_target(self.game)
        self.assertEqual(preserved.read_bytes(), b"user-drift-first")
        self.assertEqual(original.read_bytes(), b"game-original")

    def test_restore_retry_reuses_same_recovery_slot_and_preserves_prior_drift(self):
        original = self.target / "OptiScaler.ini"
        original.write_bytes(b"game-original")
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "c" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        original.write_bytes(b"user-drift-that-must-survive")

        real_copy2 = self.m.shutil.copy2
        failed_once = {"value": False}

        def fail_on_original_restore(src, dst, *args, **kwargs):
            src_path = Path(src)
            if (
                not failed_once["value"]
                and "baseline-backup" in src_path.parts
                and src_path.name == "OptiScaler.ini"
            ):
                failed_once["value"] = True
                raise OSError("simulated restore failure after drift capture")
            return real_copy2(src, dst, *args, **kwargs)

        self.m.shutil.copy2 = fail_on_original_restore
        try:
            with self.assertRaises(OSError):
                self.m.restore_target(self.game)
        finally:
            self.m.shutil.copy2 = real_copy2

        after_failure = self.m.load_baseline(self.target)
        self.assertIsNotNone(after_failure)
        slot = Path(after_failure["restore_recovery_dir"])
        preserved = slot / "OptiScaler.ini"
        self.assertTrue(preserved.is_file())
        self.assertEqual(preserved.read_bytes(), b"user-drift-that-must-survive")
        self.assertFalse(original.exists())

        result = self.m.restore_target(self.game)
        self.assertEqual(Path(result["recovery"]), slot)
        self.assertTrue(preserved.is_file())
        self.assertEqual(preserved.read_bytes(), b"user-drift-that-must-survive")
        self.assertEqual(original.read_bytes(), b"game-original")

    def test_recorded_restore_recovery_slot_escape_is_rejected(self):
        outside = self.base / "outside-recovery"
        outside.mkdir()
        baseline = self._baseline(restore_recovery_dir=str(outside))
        with self.assertRaises(self.m.Stop) as cm:
            self.m.verify_baseline_integrity(self.target, baseline, adopt_legacy=False)
        self.assertIn("escapes state root", str(cm.exception))

    def test_restore_target_refuses_live_game_before_file_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "b" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        proxy = self.target / "dxgi.dll"
        self.assertTrue(proxy.is_file())

        old_running = self.m._running_processes_under_root
        self.m._running_processes_under_root = lambda root: ["999/wine64 [cwd]"]
        try:
            with self.assertRaises(self.m.Stop) as cm:
                self.m.restore_target(self.game)
        finally:
            self.m._running_processes_under_root = old_running
        self.assertIn("Game process still using", str(cm.exception))
        self.assertTrue(proxy.is_file())
        self.assertTrue(self.m.baseline_path(self.target).is_file())

    def test_install_refuses_destructive_pending_recovery_state_before_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        sentinel = self.target / "sentinel.bin"
        sentinel.write_bytes(b"keep")
        state_dir = self.m.state_dir_for(self.target)
        state_dir.mkdir(parents=True)
        baseline = {
            "schema": 13,
            "target_dir": str(self.target),
            "exe": str(self.game.exe),
            "name": self.game.name,
            "source": "Steam",
            "appid": "123",
            "status": "destructive-pending",
            "destructive_pending": {"mode": "deep-clean", "previous_status": "active"},
            "managed_paths": [],
            "originals": {},
            "current": {},
        }
        self.m.save_json_atomic(state_dir / "baseline.json", baseline)
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(
                self.game,
                self._sm86_payload(),
                {"name": "fixture.zip", "sha256": "9" * 64, "known_tag": "fixture"},
                "sm86",
            )
        self.assertIn("destructive cleanup is still pending", str(cm.exception))
        self.assertEqual(sentinel.read_bytes(), b"keep")
        self.assertFalse((self.target / "dxgi.dll").exists())

    def test_install_refuses_live_game_before_baseline_or_file_mutation(self):
        self.game.dlss = True
        self.game.dlssg = True
        archive_meta = {"name": "fixture.zip", "sha256": "a" * 64, "known_tag": "fixture"}
        old_running = self.m._running_processes_under_root
        self.m._running_processes_under_root = lambda root: ["999/wine64 [cwd]"]
        try:
            with self.assertRaises(self.m.Stop) as cm:
                self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        finally:
            self.m._running_processes_under_root = old_running
        self.assertIn("Game process still using", str(cm.exception))
        self.assertFalse(self.m.baseline_path(self.target).exists())
        self.assertFalse((self.target / "dxgi.dll").exists())

    def test_batch_uninstall_marks_all_baselines_recovery_before_steam_metadata_restore(self):
        self.game.dlss = True
        self.game.dlssg = True
        self.game.installed = True
        self.game.reason = "INSTALLED"
        first_meta = {"name": "fixture.zip", "sha256": "4" * 64, "known_tag": "fixture"}
        self.m.install_target(self.game, self._sm86_payload(), first_meta, "sm86")

        target2 = self.drive / "SteamLibrary" / "steamapps" / "common" / "Fixture2" / "Binaries" / "Win64"
        target2.mkdir(parents=True)
        exe2 = target2 / "game2.exe"
        exe2.write_bytes(b"MZfixture2")
        game2 = self.m.Game("B", "Fixture2", target2.parents[2], "Steam", "456", None, exe2, target2)
        game2.dlss = True
        game2.dlssg = True
        game2.installed = True
        game2.reason = "INSTALLED"
        self.m.install_target(game2, self._sm86_payload(), first_meta, "sm86")

        observed = {"checked": False}
        old_restore = self.m.restore_launch_options_batch
        def inspect_then_stop(games, assume_yes=False):
            states = [self.m.load_baseline(g.target_dir) for g in games]
            self.assertTrue(all(state["status"] == "restore-pending" for state in states))
            batch_ids = {state["restore_pending"].get("batch_id") for state in states}
            self.assertEqual(len(batch_ids), 1)
            self.assertNotIn(None, batch_ids)
            observed["checked"] = True
            raise self.m.Stop("simulated metadata-stage stop")
        self.m.restore_launch_options_batch = inspect_then_stop
        try:
            with self.assertRaises(self.m.Stop):
                self.m.batch_uninstall([self.game, game2], self.drive, assume_yes=True)
        finally:
            self.m.restore_launch_options_batch = old_restore
        self.assertTrue(observed["checked"])
        self.assertTrue((self.target / "dxgi.dll").is_file())
        self.assertTrue((target2 / "dxgi.dll").is_file())
        self.assertEqual(self.m.load_baseline(self.target)["status"], "restore-pending")
        self.assertEqual(self.m.load_baseline(target2)["status"], "restore-pending")

    def test_batch_uninstall_refuses_live_game_before_steam_metadata_restore(self):
        self.game.installed = True
        self.game.reason = "INSTALLED"
        touched = {"steam_restore": False}
        old_running = self.m._running_processes_under_root
        old_restore = self.m.restore_launch_options_batch
        self.m._running_processes_under_root = lambda root: ["999/wine64 [cwd]"]
        self.m.restore_launch_options_batch = lambda *args, **kwargs: touched.__setitem__("steam_restore", True)
        try:
            with self.assertRaises(self.m.Stop) as cm:
                self.m.batch_uninstall([self.game], self.drive, assume_yes=True)
        finally:
            self.m._running_processes_under_root = old_running
            self.m.restore_launch_options_batch = old_restore
        self.assertIn("Game process still using", str(cm.exception))
        self.assertFalse(touched["steam_restore"])

    def test_batch_uninstall_aborts_before_game_mutation_when_steam_restore_fails(self):
        self.game.installed = True
        self.game.reason = "INSTALLED"
        self._baseline()
        sentinel = self.target / "managed-sentinel.dll"
        sentinel.write_bytes(b"must survive")
        touched = {"restore_target": False}
        self.m.restore_launch_options_batch = lambda *a, **k: (_ for _ in ()).throw(self.m.Stop("simulated Steam restore failure"))
        def should_not_run(game):
            touched["restore_target"] = True
            sentinel.unlink(missing_ok=True)
            return {"target": str(self.target)}
        self.m.restore_target = should_not_run

        with self.assertRaises(self.m.Stop) as cm:
            self.m.batch_uninstall([self.game], self.drive, assume_yes=True)
        self.assertIn("no game files were removed", str(cm.exception))
        self.assertFalse(touched["restore_target"])
        self.assertEqual(sentinel.read_bytes(), b"must survive")
        self.assertEqual(self.m.load_baseline(self.target)["status"], "restore-pending")

    def test_batch_uninstall_partial_file_failure_is_retryable_and_does_not_resurrect_completed_game(self):
        meta = {"name": "fixture.zip", "sha256": "b" * 64, "known_tag": "fixture"}
        self.game.dlss = True
        self.game.dlssg = True
        self.game.installed = True
        self.game.reason = "INSTALLED"
        self.m.install_target(self.game, self._sm86_payload(), meta, "sm86")

        target2 = self.drive / "SteamLibrary" / "steamapps" / "common" / "Fixture2" / "Binaries" / "Win64"
        target2.mkdir(parents=True)
        exe2 = target2 / "game2.exe"
        exe2.write_bytes(b"MZfixture2")
        game2 = self.m.Game(
            "B", "Fixture2", target2.parents[2], "Steam", "456", None,
            exe2, target2, installed=True, reason="INSTALLED",
        )
        game2.dlss = True
        game2.dlssg = True
        self.m.install_target(game2, self._sm86_payload(), meta, "sm86")

        # Metadata restoration is intentionally treated as already successful;
        # this fixture isolates the per-game file phase and its retry semantics.
        self.m.restore_launch_options_batch = lambda *a, **k: []
        self.m.write_batch_report = lambda *a, **k: self.base / "batch.md"
        real_restore = self.m.restore_target
        failed_once = {"value": False}

        def fail_second_once(game):
            if game.name == "Fixture2" and not failed_once["value"]:
                failed_once["value"] = True
                raise OSError("simulated second-game restore failure")
            return real_restore(game)

        self.m.restore_target = fail_second_once
        self.m.batch_uninstall([self.game, game2], self.drive, assume_yes=True)

        # The first game is durably retired. The failed second game remains an
        # active managed install and still has its payload for a later retry.
        self.assertIsNone(self.m.load_baseline(self.target))
        self.assertFalse((self.target / "dxgi.dll").exists())
        self.assertIsNotNone(self.m.load_baseline(target2))
        self.assertTrue((target2 / "dxgi.dll").is_file())

        # Retry only the failed game. Already-restored Steam metadata is
        # idempotent/no-op here, and the completed first game stays retired.
        self.m.restore_target = real_restore
        self.m.batch_uninstall([game2], self.drive, assume_yes=True)
        self.assertIsNone(self.m.load_baseline(target2))
        self.assertFalse((target2 / "dxgi.dll").exists())
        self.assertIsNone(self.m.load_baseline(self.target))


    def test_fresh_install_does_not_overwrite_unknown_dxgi_and_falls_back_to_version(self):
        self.game.dlss = True
        self.game.dlssg = True
        original = b"game-owned-unknown-dxgi"
        write_minimal_pe(self.exe, ["version.dll"])
        (self.target / "dxgi.dll").write_bytes(original)
        archive_meta = {"name": "fixture.zip", "sha256": "8" * 64, "known_tag": "fixture"}

        row = self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertEqual(row["proxy"], "version.dll")
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), original)
        self.assertTrue((self.target / "version.dll").is_file())

        self.m.restore_target(self.game)
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), original)
        self.assertFalse((self.target / "version.dll").exists())

    def test_fresh_install_refuses_when_both_validated_optiscaler_proxies_are_unknown_owned(self):
        self.game.dlss = True
        self.game.dlssg = True
        (self.target / "dxgi.dll").write_bytes(b"game-owned-dxgi")
        (self.target / "version.dll").write_bytes(b"game-owned-version")
        archive_meta = {"name": "fixture.zip", "sha256": "9" * 64, "known_tag": "fixture"}

        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertIn("No safe OptiScaler proxy", str(cm.exception))
        self.assertFalse(self.m.baseline_path(self.target).exists())
        self.assertEqual((self.target / "dxgi.dll").read_bytes(), b"game-owned-dxgi")
        self.assertEqual((self.target / "version.dll").read_bytes(), b"game-owned-version")


    def test_fresh_install_refuses_unproven_version_fallback_when_dxgi_is_unknown_owned(self):
        self.game.dlss = True
        self.game.dlssg = True
        (self.target / "dxgi.dll").write_bytes(b"game-owned-dxgi")
        archive_meta = {"name": "fixture.zip", "sha256": "0" * 64, "known_tag": "fixture"}
        with self.assertRaises(self.m.Stop) as cm:
            self.m.install_target(self.game, self._sm86_payload(), archive_meta, "sm86")
        self.assertIn("No safe OptiScaler proxy", str(cm.exception))
        self.assertFalse((self.target / "version.dll").exists())
        self.assertFalse(self.m.baseline_path(self.target).exists())




    def test_game_file_scanner_prunes_nested_mounts_symlinks_and_special_evidence(self):
        root = self.base / "scan-root"
        root.mkdir()
        normal = root / "game.exe"
        normal.write_bytes(b"MZ")
        mounted = root / "Mounted"
        mounted.mkdir()
        mounted_evidence = mounted / "nvngx_dlss.dll"
        mounted_evidence.write_bytes(b"outside-ish")
        external = self.base / "external-nvngx_dlssg.dll"
        external.write_bytes(b"external")
        link = root / "nvngx_dlssg.dll"
        link.symlink_to(external)

        old_mount = self.m._path_is_mount
        self.m._path_is_mount = lambda path: Path(path).name == "Mounted"
        try:
            found = list(self.m.iter_game_files(root))
        finally:
            self.m._path_is_mount = old_mount

        self.assertIn(normal, found)
        self.assertNotIn(mounted_evidence, found)
        self.assertNotIn(link, found)

    def test_discovery_skips_manifest_installdir_that_escapes_common(self):
        drive = self.base / "DiscoverDrive"
        steamapps = drive / "SteamLibrary" / "steamapps"
        common = steamapps / "common"
        common.mkdir(parents=True)
        escaped = steamapps / "Escape"
        escaped.mkdir()
        (escaped / "game.exe").write_bytes(b"MZ")
        (escaped / "nvngx_dlss.dll").write_bytes(b"dlss")
        (escaped / "nvngx_dlssg.dll").write_bytes(b"dlssg")
        manifest = steamapps / "appmanifest_123.acf"
        manifest.write_text(
            '"AppState"\n{\n"appid" "123"\n"name" "Escaped Fixture"\n"installdir" "../Escape"\n}\n',
            encoding="utf-8",
        )

        games = self.m.discover_games(drive)
        self.assertFalse(any(g.appid == "123" for g in games))

    def test_default_dlss_archive_selection_skips_newer_unpinned_candidate(self):
        self.m.DEFAULT_DOWNLOAD_DIR = self.base / "Downloads" / "Compressed"
        self.m.DEFAULT_DOWNLOAD_DIR.mkdir(parents=True)

        good = self.m.DEFAULT_DOWNLOAD_DIR / "dlss-unlocked-standalone-DLSSNR-v-good.zip"
        bad = self.m.DEFAULT_DOWNLOAD_DIR / "dlss-unlocked-standalone-DLSSNR-v-bad.zip"
        good.write_bytes(b"known-good-provider-bytes")
        bad.write_bytes(b"newer-but-untrusted-provider-bytes")
        digest = hashlib.sha256(good.read_bytes()).hexdigest()
        self.m.KNOWN_ARCHIVES = {
            "official-fixture.zip": {"sha256": digest, "tag": "fixture"},
        }
        # Make the corrupt candidate decisively newer so filename/mtime-only
        # selection would choose the wrong file.
        os.utime(good, ns=(1_000_000_000, 1_000_000_000))
        os.utime(bad, ns=(2_000_000_000, 2_000_000_000))

        self.assertEqual(self.m.find_default_archive(), bad)
        self.assertEqual(self.m.find_pinned_default_archive(), good.resolve())
        self.assertEqual(self.m.choose_archive(), good.resolve())

    def test_rtxmfg_local_discovery_skips_bad_download_and_uses_valid_cache(self):
        source = self.base / "source-valid.zip"
        digest = self._write_rtxmfg_zip(source)
        self.m.DEFAULT_DOWNLOAD_DIR = self.base / "Downloads" / "Compressed"
        self.m.RTXMFG_CACHE_DIR = self.base / "cache"
        self.m.RTXMFG_PROVIDER = {
            "version": "fixture", "archive": "RTXMFG-fixture.zip",
            "sha256": digest, "url": "https://example.invalid/RTXMFG-fixture.zip",
        }
        self.m.DEFAULT_DOWNLOAD_DIR.mkdir(parents=True)
        bad = self.m.DEFAULT_DOWNLOAD_DIR / "RTXMFG-fixture.zip"
        bad.write_bytes(b"stale corrupt archive")
        self.m.RTXMFG_CACHE_DIR.mkdir(parents=True)
        good = self.m.RTXMFG_CACHE_DIR / "RTXMFG-fixture.zip"
        good.write_bytes(source.read_bytes())

        found = self.m.find_local_rtxmfg_archive()
        self.assertEqual(found, good.resolve())
        self.assertEqual(self.m.ensure_rtxmfg_archive(allow_download=False), good.resolve())

    def test_refresh_backup_writers_refuse_nested_backup_symlink_pivots(self):
        for child, operation in (("files", "extend"), ("external-adopted", "adopt")):
            with self.subTest(child=child):
                # Use a fresh target per subtest so state from one case cannot
                # influence the other.
                target = self.drive / f"Nested-{child}" / "Binaries" / "Win64"
                target.mkdir(parents=True)
                exe = target / "game.exe"
                exe.write_bytes(b"MZ")
                baseline = {
                    "schema": 13, "status": "active", "created_utc": self.m.now_iso(),
                    "name": child, "source": "Steam", "appid": "999",
                    "exe": str(exe), "target_dir": str(target),
                    "originals": {"dxgi.dll": {"kind": "file", "existed": False}},
                    "managed_paths": ["dxgi.dll"], "history": [],
                    "current": {"installed_hashes": {}},
                }
                state = self.m._validated_state_dir(target)
                state.mkdir(parents=True)
                self.m.save_json_atomic(self.m.baseline_path(target), baseline)
                backup_root = state / "baseline-backup"
                backup_root.mkdir()
                outside = self.base / f"outside-{child}"
                outside.mkdir()
                (backup_root / child).symlink_to(outside, target_is_directory=True)

                if operation == "extend":
                    live = target / "version.dll"
                    live.write_bytes(b"external-version")
                    call = lambda: self.m.extend_baseline_for_new_paths(baseline, target, {"version.dll"})
                else:
                    live = target / "dxgi.dll"
                    live.write_bytes(b"external-dxgi")
                    call = lambda: self.m.adopt_external_file_as_original(baseline, target, "dxgi.dll")

                with self.assertRaises(self.m.Stop) as cm:
                    call()
                self.assertIn("symlink", str(cm.exception).lower())
                self.assertEqual(list(outside.iterdir()), [])
                self.assertTrue(live.is_file())

    def test_refresh_backup_writer_refuses_baseline_backup_root_symlink_pivot(self):
        baseline = self._baseline()
        state = self.m._validated_state_dir(self.target, require_exists=True)
        outside = self.base / "outside-refresh-backup"
        outside.mkdir()
        backup_root = state / "baseline-backup"
        backup_root.symlink_to(outside, target_is_directory=True)
        external = self.target / "version.dll"
        external.write_bytes(b"external-version")

        with self.assertRaises(self.m.Stop) as cm:
            self.m.extend_baseline_for_new_paths(baseline, self.target, {"version.dll"})
        self.assertIn("Baseline backup root symlink refused", str(cm.exception))
        self.assertEqual(list(outside.iterdir()), [])
        self.assertEqual(external.read_bytes(), b"external-version")



if __name__ == "__main__":
    unittest.main(verbosity=2)
