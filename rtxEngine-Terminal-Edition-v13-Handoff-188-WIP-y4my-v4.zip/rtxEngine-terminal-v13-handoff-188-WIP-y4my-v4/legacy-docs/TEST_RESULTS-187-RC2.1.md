# Test Results — Handoff 187 RC2.1

## Automated gate
- `pytest -q`: **200 passed, 10 subtests passed**
- `python3 -m py_compile rtxEngine-terminal-v13.py`: **PASS**
- Bundled Ada runtime SHA-256: **PASS**
  - expected/actual: `95580ebc7d2f562d6d99cd798587f757a51cd7bd52e24b0895c42414c3a3c2e8`
- Runtime identity manifest/capability markers remain validated.

## RC2.1 launch-safety regressions

New coverage proves that:

- newly generated launch options do not add `PROTON_NVIDIA_NVCUDA`;
- an RC2-synced Steam entry containing legacy NVCUDA is repaired in place by LaunchOptions sync;
- existing DLL overrides are merged rather than lost;
- Halo-style `dwmapi=n,b` survives while rtxEngine adds its own proxy;
- MangoHud/gamescope command structure remains intact;
- managed-looking tokens after a wrapper command fail closed instead of being reordered into environment assignments.


## RC1 live evidence carried into RC2
Six titles worked with the exact integrated v3e core: Avowed, Clair Obscur: Expedition 33, FINAL FANTASY VII REBIRTH, Forza Horizon 6, Halo Campaign Evolved, and The Outer Worlds 2.

Twelve titles exposed a second compatibility problem class (no hook/no MFG, crash, hang, or launch failure). RC2 does not hardcode those titles; it hardens injection/configuration generically and records runtime evidence.

## New RC2 regression coverage
- imported supported proxy is preferred for an unproven integrated Ada target;
- RC1 `dxgi.dll` fallback can migrate safely to a positive imported proxy;
- a proxy with a real `NativeMfgMenu.v3e` applied marker is preserved;
- ReShade `dxgi.dll` remains untouched while launch options override ReShade + alternate OptiScaler proxy;
- Ada spoofing is minimized and native SR route is preserved;
- EOS overlay detection turns on OptiScaler's built-in overlay blocker only where detected;
- runtime audit distinguishes actual MFG execution from overlay/menu visibility.

## Live gate
**Pending RC2 user validation.**

First retest:
1. The Outer Worlds 2 or Avowed — known-good regression baseline;
2. Cyberpunk 2077 — previous flatline case;
3. Avatar: Frontiers of Pandora — previous no-hook/no-MFG case.

Do not call RC2 universal-runtime-verified until those live results are known. NR is intentionally disabled throughout this milestone.
