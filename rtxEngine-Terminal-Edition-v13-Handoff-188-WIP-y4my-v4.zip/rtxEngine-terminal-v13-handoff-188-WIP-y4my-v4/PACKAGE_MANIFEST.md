# Package Manifest — Handoff 188 WIP y4my v4

- `rtxEngine-terminal-v13.py` — exact current partial 188 implementation
- `tests/test_v13_core_hardening.py` — inherited suite, not yet fully migrated
- `tests/test_v13_deep_clean.py`
- `tests/test_v13_pristine_reset.py`
- `RUN_TESTS.sh`
- `DEVELOPMENT_HANDOFF.md` — authoritative current handoff
- `TEST_RESULTS.md` — current gate summary
- `CURRENT_TEST_OUTPUT.txt` — complete pytest output from packaging time
- `legacy-docs/` — 187 RC2.1 docs retained only for migration/history context

No y4my binary release asset is bundled in this handoff. The source pins and verifies the exact upstream release archive at runtime.
